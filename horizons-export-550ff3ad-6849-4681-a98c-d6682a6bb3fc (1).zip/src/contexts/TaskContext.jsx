
import React, { createContext, useState, useEffect, useContext } from 'react';
import { BookingContext } from '@/contexts/BookingContext';
import { LeadContext } from '@/contexts/LeadContext';
import { NotificationContext } from '@/contexts/NotificationContext';

export const TaskContext = createContext(null);

const generateId = (prefix = 'EGS') => {
  const timestamp = Date.now().toString().slice(-6);
  const random = Math.floor(Math.random() * 1000).toString().padStart(3, '0');
  return `${prefix}${timestamp}${random}`;
};

export function TaskProvider({ children }) {
  const [tasks, setTasks] = useState([]);
  const bookingContext = useContext(BookingContext);
  const leadContext = useContext(LeadContext);
  const notificationContext = useContext(NotificationContext);

  const saveToStorage = (key, data) => {
    localStorage.setItem(key, JSON.stringify(data));
  };

  useEffect(() => {
    const savedTasks = localStorage.getItem('egoa_tasks');
    setTasks(savedTasks ? JSON.parse(savedTasks) : []);
  }, []);

  const createTaskFromBooking = (booking) => {
     const task = {
      id: generateId('TSK'),
      originalId: booking.id,
      vleId: null, 
      type: 'booking', 
      status: 'pending_assignment', 
      taskPhase: 0, 
      assignedAt: null,
      serviceName: booking.serviceName,
      fee: booking.fee,
      customerName: booking.customerDetails.name, 
      customerPhone: booking.customerDetails.phone,
      customerId: booking.customerId,
      documents: [...booking.documents], 
      history: [{ status: 'pending_assignment', timestamp: new Date().toISOString(), remarks: 'Task created from booking, awaiting assignment.' }]
    };
    const newTasks = [...tasks, task];
    setTasks(newTasks);
    saveToStorage('egoa_tasks', newTasks);
    if (notificationContext) {
      notificationContext.addNotification('admin-1', `New task created from booking ${booking.id} for ${booking.serviceName}. Needs assignment.`, 'info', `/admin-dashboard?tab=assign-tasks&taskId=${task.id}`, 'New Task for Assignment');
    }
    return task;
  };

  const createTaskFromLead = (lead) => {
    const task = {
      id: generateId('TSK'),
      originalId: lead.id,
      vleId: null, 
      type: 'lead', 
      status: 'pending_assignment', 
      taskPhase: 0, 
      assignedAt: null,
      serviceName: lead.serviceName,
      fee: lead.fee,
      customerName: lead.customerName, 
      customerPhone: lead.customerPhone,
      generatedByVleId: lead.vleId, 
      documents: [...lead.documents], 
      history: [{ status: 'pending_assignment', timestamp: new Date().toISOString(), remarks: 'Task created from lead, awaiting assignment.' }]
    };
    const newTasks = [...tasks, task];
    setTasks(newTasks);
    saveToStorage('egoa_tasks', newTasks);
    if (notificationContext) {
      notificationContext.addNotification('admin-1', `New task created from lead ${lead.id} for ${lead.serviceName}. Needs assignment.`, 'info', `/admin-dashboard?tab=assign-tasks&taskId=${task.id}`, 'New Task for Assignment');
    }
    return task;
  };


  const assignTask = (originalItemId, vleId, itemType) => {
    const existingTask = tasks.find(t => t.originalId === originalItemId && t.type === itemType);
    let taskToUpdate;

    if (existingTask) {
      taskToUpdate = {
        ...existingTask,
        vleId,
        status: 'assigned',
        taskPhase: 1,
        assignedAt: new Date().toISOString(),
        history: [...(existingTask.history || []), { status: 'assigned', timestamp: new Date().toISOString(), remarks: `Assigned to VLE ${vleId}` }]
      };
      const newTasks = tasks.map(t => t.id === existingTask.id ? taskToUpdate : t);
      setTasks(newTasks);
      saveToStorage('egoa_tasks', newTasks);
    } else {
      console.error("Cannot assign: Task not found for item ID", originalItemId, "and type", itemType);
      return null;
    }
    
    if (itemType === 'booking' && bookingContext) {
      bookingContext.updateBookingStatusAndHistory(originalItemId, 'assigned', `Assigned to VLE ${vleId}`);
    } else if (itemType === 'lead' && leadContext) {
      leadContext.updateLeadStatusAndHistory(originalItemId, 'assigned', `Assigned to VLE ${vleId}`);
    }
    return taskToUpdate;
  };

  const updateTask = (taskId, updates) => {
    let taskToUpdate;
    const oldTask = tasks.find(t => t.id === taskId);
    if (!oldTask) return null;

    const newTasks = tasks.map(t => {
      if (t.id === taskId) {
        taskToUpdate = { 
          ...t, 
          ...updates, 
          updatedAt: new Date().toISOString(),
          history: [...(t.history || []), { status: updates.status || t.status, timestamp: new Date().toISOString(), remarks: updates.remarks || `Status updated to ${updates.status}` }]
        };
        
        let finalStatusForOriginalItem = taskToUpdate.status;
        let remarkForOriginalItem = updates.remarks || `Status updated to ${updates.status}`;
        let customerNotificationMessage = `Status of your application for "${taskToUpdate.serviceName}" updated to ${finalStatusForOriginalItem.replace(/_/g, ' ')}.`;
        let vleNotificationMessage = `Task ${taskToUpdate.id} (${taskToUpdate.serviceName}) status updated to ${finalStatusForOriginalItem.replace(/_/g, ' ')}.`;
        let generatingVleNotificationMessage = `Task for your lead ${taskToUpdate.originalId} (${taskToUpdate.serviceName}) status updated to ${finalStatusForOriginalItem.replace(/_/g, ' ')}.`;


        if (updates.status === 'completed') {
          taskToUpdate.status = 'pending_commission_approval'; 
          taskToUpdate.history.push({ status: 'pending_commission_approval', timestamp: new Date().toISOString(), remarks: 'Task completed by VLE, awaiting commission approval.' });
          finalStatusForOriginalItem = 'completed'; 
          remarkForOriginalItem = 'Application processed and completed.';
          customerNotificationMessage = `Your application for "${taskToUpdate.serviceName}" is complete! Certificate may be available.`;
          vleNotificationMessage = `Task ${taskToUpdate.id} (${taskToUpdate.serviceName}) completed. Pending commission approval.`;
          generatingVleNotificationMessage = `Task for your lead ${taskToUpdate.originalId} (${taskToUpdate.serviceName}) has been completed by the assigned VLE.`;
          if (notificationContext) notificationContext.addNotification('admin-1', `Task ${taskToUpdate.id} (${taskToUpdate.serviceName}) completed by VLE. Pending commission approval.`, 'info', `/admin-dashboard?tab=commissions&taskId=${taskToUpdate.id}`, 'Task Completed - Needs Approval');
        } else if (taskToUpdate.status === 'pending_commission_approval' || taskToUpdate.status === 'commission_approved' || taskToUpdate.status === 'commission_rejected') {
          finalStatusForOriginalItem = 'completed';
          remarkForOriginalItem = 'Application processed and completed.';
          customerNotificationMessage = `Your application for "${taskToUpdate.serviceName}" is processed.`;
        }
        
        if (taskToUpdate.type === 'booking' && bookingContext) {
          bookingContext.updateBookingStatusAndHistory(taskToUpdate.originalId, finalStatusForOriginalItem, remarkForOriginalItem);
          if (notificationContext && taskToUpdate.customerId && oldTask.status !== finalStatusForOriginalItem) {
            notificationContext.addNotification(taskToUpdate.customerId, customerNotificationMessage, 'info', `/customer-dashboard?tab=my-bookings&bookingId=${taskToUpdate.originalId}`, 'Application Update');
          }
        } else if (taskToUpdate.type === 'lead' && leadContext) {
          leadContext.updateLeadStatusAndHistory(taskToUpdate.originalId, finalStatusForOriginalItem, remarkForOriginalItem);
           if (notificationContext && taskToUpdate.generatedByVleId && oldTask.status !== finalStatusForOriginalItem) {
            notificationContext.addNotification(taskToUpdate.generatedByVleId, generatingVleNotificationMessage, 'info', `/vle-dashboard?tab=my-leads&leadId=${taskToUpdate.originalId}`, 'Lead Task Update');
          }
        }
        
        if (notificationContext && taskToUpdate.vleId && oldTask.status !== finalStatusForOriginalItem && updates.status !== 'completed') {
           notificationContext.addNotification(taskToUpdate.vleId, vleNotificationMessage, 'info', `/vle-dashboard?tab=assigned-tasks&taskId=${taskToUpdate.id}`, 'Task Status Update');
        }
        if (notificationContext && updates.status === 'completed' && taskToUpdate.vleId) {
           notificationContext.addNotification(taskToUpdate.vleId, vleNotificationMessage, 'success', `/vle-dashboard?tab=assigned-tasks&taskId=${taskToUpdate.id}`, 'Task Completed');
        }


        return taskToUpdate;
      }
      return t;
    });
    setTasks(newTasks);
    saveToStorage('egoa_tasks', newTasks);
    return taskToUpdate;
  };
  
  const reassignTask = (taskId, remarks = 'Task rejected, pending re-assignment') => {
    const task = tasks.find(t => t.id === taskId);
    if (!task) return;

    const updates = { status: 'pending_assignment', taskPhase: 0, vleId: null, remarks }; 
    
    const newTasks = tasks.map(t => t.id === taskId ? { ...t, ...updates, history: [...(t.history || []), { status: 'pending_assignment', timestamp: new Date().toISOString(), remarks}] } : t);
    setTasks(newTasks);
    saveToStorage('egoa_tasks', newTasks);

    if (task.type === 'booking' && bookingContext) {
        bookingContext.updateBookingStatusAndHistory(task.originalId, 'pending_assignment', remarks);
    } else if (task.type === 'lead' && leadContext) {
        leadContext.updateLeadStatusAndHistory(task.originalId, 'pending_assignment', remarks);
    }
    if (notificationContext) {
      notificationContext.addNotification('admin-1', `Task ${taskId} (${task.serviceName}) was rejected by VLE and needs re-assignment. Reason: ${remarks}`, 'warning', `/admin-dashboard?tab=assign-tasks&taskId=${taskId}`, 'Task Rejected - Needs Re-assignment');
      if (task.customerId) {
        notificationContext.addNotification(task.customerId, `There was an issue with your application for ${task.serviceName}. It is being re-assigned.`, 'info', `/customer-dashboard?tab=my-bookings&bookingId=${task.originalId}`, 'Application Update');
      }
    }
  };

  const addDocumentsToTask = (taskId, newDocs, remarks, newStatus) => {
    const task = tasks.find(t => t.id === taskId);
    if (!task) return;

    const updatedDocs = [...(task.documents || []), ...newDocs];
    const historyEntry = { status: newStatus || task.status, timestamp: new Date().toISOString(), remarks: remarks || `Added ${newDocs.length} new document(s).` };
    
    let updatedTask = { ...task, documents: updatedDocs, history: [...(task.history || []), historyEntry], status: newStatus || task.status };
    
    let finalStatusForOriginalItem = updatedTask.status;
    let remarkForOriginalItem = remarks || `Added ${newDocs.length} new document(s).`;
    let customerNotificationMessage = `Documents updated for your application "${updatedTask.serviceName}".`;
    let vleNotificationMessage = `Documents updated for task ${updatedTask.id} (${updatedTask.serviceName}).`;
    let generatingVleNotificationMessage = `Documents updated for task related to your lead ${updatedTask.originalId} (${updatedTask.serviceName}).`;


    if (newStatus === 'completed') {
        updatedTask.status = 'pending_commission_approval';
        updatedTask.history.push({ status: 'pending_commission_approval', timestamp: new Date().toISOString(), remarks: 'Task completed by VLE, awaiting commission approval.' });
        finalStatusForOriginalItem = 'completed';
        remarkForOriginalItem = 'Application processed and completed.';        customerNotificationMessage = `Your application for "${updatedTask.serviceName}" is complete! Certificate may be available.`;
        vleNotificationMessage = `Task ${updatedTask.id} (${updatedTask.serviceName}) completed. Pending commission approval.`;
        generatingVleNotificationMessage = `Task for your lead ${updatedTask.originalId} (${updatedTask.serviceName}) has been completed by the assigned VLE.`;
        if (notificationContext) notificationContext.addNotification('admin-1', `Task ${updatedTask.id} (${updatedTask.serviceName}) completed by VLE. Pending commission approval.`, 'info', `/admin-dashboard?tab=commissions&taskId=${updatedTask.id}`, 'Task Completed - Needs Approval');
    }

    const newTasks = tasks.map(t => t.id === taskId ? updatedTask : t);
    setTasks(newTasks);
    saveToStorage('egoa_tasks', newTasks);

    if (task.type === 'booking' && bookingContext) {
      bookingContext.addDocumentsToBooking(task.originalId, newDocs, remarkForOriginalItem, finalStatusForOriginalItem);
       if (notificationContext && task.customerId) {
         notificationContext.addNotification(task.customerId, customerNotificationMessage, 'info', `/customer-dashboard?tab=my-bookings&bookingId=${task.originalId}`, 'Application Documents Update');
       }
    } else if (task.type === 'lead' && leadContext) {
      leadContext.addDocumentsToLead(task.originalId, newDocs, remarkForOriginalItem, finalStatusForOriginalItem);
      if (notificationContext && task.generatedByVleId) {
        notificationContext.addNotification(task.generatedByVleId, generatingVleNotificationMessage, 'info', `/vle-dashboard?tab=my-leads&leadId=${task.originalId}`, 'Lead Task Documents Update');
      }
    }
    
    if (notificationContext && task.vleId && newStatus !== 'completed') {
        notificationContext.addNotification(task.vleId, vleNotificationMessage, 'info', `/vle-dashboard?tab=assigned-tasks&taskId=${task.id}`, 'Task Documents Update');
    }
    if (notificationContext && newStatus === 'completed' && task.vleId) {
        notificationContext.addNotification(task.vleId, vleNotificationMessage, 'success', `/vle-dashboard?tab=assigned-tasks&taskId=${task.id}`, 'Task Completed');
    }

    return updatedTask;
  };

  const approveCommission = (taskId, adminRemarks) => {
    setTasks(prevTasks => {
      const newTasks = prevTasks.map(t => {
        if (t.id === taskId && t.status === 'pending_commission_approval') {
          const updatedTask = {
            ...t,
            status: 'commission_approved',
            taskPhase: 5, 
            history: [...(t.history || []), { status: 'commission_approved', timestamp: new Date().toISOString(), remarks: adminRemarks || 'Commission approved by admin.' }]
          };
          if (updatedTask.type === 'booking' && bookingContext) {
            bookingContext.updateBookingStatusAndHistory(updatedTask.originalId, 'completed', 'Application processed and completed.');
          } else if (updatedTask.type === 'lead' && leadContext) {
            leadContext.updateLeadStatusAndHistory(updatedTask.originalId, 'completed', 'Application processed and completed.');
          }
          if (notificationContext) {
            if (updatedTask.vleId) {
              notificationContext.addNotification(updatedTask.vleId, `Commission for task ${updatedTask.id} (${updatedTask.serviceName}) has been approved. Payout processed.`, 'success', `/vle-dashboard?tab=vle-wallet&taskId=${updatedTask.id}`, 'Commission Approved');
            }
            if (updatedTask.type === 'lead' && updatedTask.generatedByVleId && updatedTask.generatedByVleId !== updatedTask.vleId) {
              notificationContext.addNotification(updatedTask.generatedByVleId, `Commission for your generated lead ${updatedTask.originalId} (${updatedTask.serviceName}) has been approved. Payout processed.`, 'success', `/vle-dashboard?tab=vle-wallet&leadId=${updatedTask.originalId}`, 'Lead Commission Approved');
            }
          }
          return updatedTask;
        }
        return t;
      });
      saveToStorage('egoa_tasks', newTasks);
      return newTasks;
    });
  };

  const rejectCommission = (taskId, adminRemarks) => {
     setTasks(prevTasks => {
      const newTasks = prevTasks.map(t => {
        if (t.id === taskId && t.status === 'pending_commission_approval') {
          const updatedTask = {
            ...t,
            status: 'commission_rejected', 
            history: [...(t.history || []), { status: 'commission_rejected', timestamp: new Date().toISOString(), remarks: adminRemarks || 'Commission rejected by admin.' }]
          };
          if (updatedTask.type === 'booking' && bookingContext) {
            bookingContext.updateBookingStatusAndHistory(updatedTask.originalId, 'completed', 'Application processed and completed.');
          } else if (updatedTask.type === 'lead' && leadContext) {
            leadContext.updateLeadStatusAndHistory(updatedTask.originalId, 'completed', 'Application processed and completed.');
          }
          if (notificationContext) {
            if (updatedTask.vleId) {
              notificationContext.addNotification(updatedTask.vleId, `Commission for task ${updatedTask.id} (${updatedTask.serviceName}) has been rejected. Reason: ${adminRemarks}`, 'error', `/vle-dashboard?tab=assigned-tasks&taskId=${updatedTask.id}`, 'Commission Rejected');
            }
             if (updatedTask.type === 'lead' && updatedTask.generatedByVleId && updatedTask.generatedByVleId !== updatedTask.vleId) {
              notificationContext.addNotification(updatedTask.generatedByVleId, `Commission for your generated lead ${updatedTask.originalId} (${updatedTask.serviceName}) has been rejected. Reason: ${adminRemarks}`, 'error', `/vle-dashboard?tab=my-leads&leadId=${updatedTask.originalId}`, 'Lead Commission Rejected');
            }
          }
          return updatedTask;
        }
        return t;
      });
      saveToStorage('egoa_tasks', newTasks);
      return newTasks;
    });
  };


  const clearTasks = () => {
    setTasks([]);
    saveToStorage('egoa_tasks', []);
  };

  const value = {
    tasks,
    createTaskFromBooking,
    createTaskFromLead,
    assignTask,
    updateTask,
    reassignTask,
    addDocumentsToTask,
    approveCommission,
    rejectCommission,
    clearTasks
  };

  return <TaskContext.Provider value={value}>{children}</TaskContext.Provider>;
}
