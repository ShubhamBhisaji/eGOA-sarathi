
import React, { createContext, useState, useEffect, useContext } from 'react';
import { useAuth } from '@/hooks/useAuth.jsx'; 

export const WalletContext = createContext(null);

const generateId = (prefix = 'TXN') => {
  const timestamp = Date.now().toString().slice(-6);
  const random = Math.floor(Math.random() * 1000).toString().padStart(3, '0');
  return `${prefix}${timestamp}${random}`;
};

export function WalletProvider({ children }) {
  const { DEMO_USERS, updateUserInStorage, user: loggedInUser } = useAuth();
  const [platformCommission, setPlatformCommission] = useState(0);

  useEffect(() => {
    const savedCommission = localStorage.getItem('egoa_platform_commission');
    setPlatformCommission(savedCommission ? parseFloat(savedCommission) : 0);
  }, []);

  const updateWalletAndHistory = (userId, amount, type, description, serviceId = null, commission = null) => {
    const userToUpdate = DEMO_USERS.find(u => u.id === userId);
    if (!userToUpdate) return false;

    const newBalance = (userToUpdate.walletBalance || 0) + amount; // amount can be negative for debit
    const transaction = {
      id: generateId(),
      type,
      amount: Math.abs(amount),
      description,
      serviceId,
      commission,
      timestamp: new Date().toISOString(),
      balanceAfterTransaction: newBalance
    };
    
    const updatedUser = {
      ...userToUpdate,
      walletBalance: newBalance,
      transactionHistory: [transaction, ...(userToUpdate.transactionHistory || [])]
    };
    
    return updateUserInStorage(userId, updatedUser);
  };

  const addDemoMoney = (userId, amount, remarks = "Demo money added by user.") => {
    if (amount <= 0) return { success: false, error: "Amount must be positive." };
    const success = updateWalletAndHistory(userId, amount, 'deposit', remarks);
    return { success };
  };

  const withdrawDemoMoney = (userId, amount, bankAccountNumber, remarks = "Withdrawal request.") => {
    if (amount <= 0) return { success: false, error: "Amount must be positive." };
    const user = DEMO_USERS.find(u => u.id === userId);
    if (!user || (user.walletBalance || 0) < amount) {
      return { success: false, error: "Insufficient balance." };
    }
    if (!user.bankAccounts || !user.bankAccounts.find(acc => acc.accountNumber === bankAccountNumber)) {
        return { success: false, error: "Selected bank account not found." };
    }
    const success = updateWalletAndHistory(userId, -amount, 'withdrawal', `${remarks} to A/C: ${bankAccountNumber}`);
    return { success };
  };
  
  const debitUserWallet = (userId, amount, description) => {
    if (amount <= 0) return false;
    return updateWalletAndHistory(userId, -amount, 'debit', description);
  };

  const creditUserWallet = (userId, amount, description) => {
    if (amount <= 0) return false;
    return updateWalletAndHistory(userId, amount, 'credit', description);
  };

  const processTaskCompletionPayouts = (taskDetails) => {
    const { assignedVleId, serviceFee, serviceId, serviceName, type, generatedByVleId } = taskDetails;

    const adminCommissionRate = 0.10;
    const adminCommissionAmount = serviceFee * adminCommissionRate;
    let assignedVlePayout = 0;
    let generatingVlePayout = 0;
    let success = true;

    if (type === 'lead' && generatedByVleId) {
      const leadVleShare = 0.45;
      const assignedVleShare = 0.45;
      assignedVlePayout = serviceFee * assignedVleShare;
      generatingVlePayout = serviceFee * leadVleShare;

      if (assignedVleId) {
        const assignedVleCreditSuccess = updateWalletAndHistory(assignedVleId, assignedVlePayout, 'payout', `Payout (assigned) for lead: ${serviceName} (ID: ${serviceId})`, serviceId, adminCommissionAmount);
        if (!assignedVleCreditSuccess) success = false;
      }
      
      const generatingVleCreditSuccess = updateWalletAndHistory(generatedByVleId, generatingVlePayout, 'payout', `Payout (generated) for lead: ${serviceName} (ID: ${serviceId})`, serviceId, null);
      if (!generatingVleCreditSuccess) success = false;

    } else { // Booking or lead without a generating VLE (should not happen for leads with new logic)
      const assignedVleShare = 0.90;
      assignedVlePayout = serviceFee * assignedVleShare;
      if (assignedVleId) {
        const assignedVleCreditSuccess = updateWalletAndHistory(assignedVleId, assignedVlePayout, 'payout', `Payout for service: ${serviceName} (ID: ${serviceId})`, serviceId, adminCommissionAmount);
        if (!assignedVleCreditSuccess) success = false;
      }
    }
    
    if (success) {
      setPlatformCommission(prev => {
        const newTotal = prev + adminCommissionAmount;
        localStorage.setItem('egoa_platform_commission', newTotal.toString());
        return newTotal;
      });
      console.log(`Platform earned ₹${adminCommissionAmount.toFixed(2)} commission for service ${serviceId}`);
      return { success: true, assignedVlePayout, generatingVlePayout, adminCommissionAmount };
    }
    return { success: false, error: "One or more VLE payouts failed." };
  };


  const issueRefundToCustomer = (customerId, amount, serviceId, serviceName, remarks = "Refund processed by admin.") => {
    if (amount <= 0) return { success: false, error: "Refund amount must be positive." };
    const success = updateWalletAndHistory(customerId, amount, 'refund', `${remarks} For Service: ${serviceName} (ID: ${serviceId})`, serviceId);
    return { success };
  };

  const checkBalance = (userId, amount) => {
    const user = DEMO_USERS.find(u => u.id === userId);
    return user && (user.walletBalance || 0) >= amount;
  };

  const getWalletDetails = (userId) => {
    const user = DEMO_USERS.find(u => u.id === userId);
    if (!user) return null;
    return {
      balance: user.walletBalance || 0,
      transactions: user.transactionHistory || []
    };
  };

  const value = {
    addDemoMoney,
    withdrawDemoMoney,
    debitUserWallet,
    creditUserWallet,
    processTaskCompletionPayouts,
    issueRefundToCustomer,
    checkBalance,
    getWalletDetails,
    platformCommission
  };

  return <WalletContext.Provider value={value}>{children}</WalletContext.Provider>;
}
