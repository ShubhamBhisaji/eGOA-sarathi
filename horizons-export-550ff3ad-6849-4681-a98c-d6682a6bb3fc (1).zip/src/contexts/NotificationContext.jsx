
import React, { createContext, useState, useEffect, useContext } from 'react';
import { useAuth } from '@/hooks/useAuth.jsx';

export const NotificationContext = createContext(null);

const generateId = () => `notif-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`;

export function NotificationProvider({ children }) {
  const [notifications, setNotifications] = useState([]);
  const { user } = useAuth();

  const saveToStorage = (data) => {
    localStorage.setItem('egoa_notifications', JSON.stringify(data));
  };

  useEffect(() => {
    const savedNotifications = localStorage.getItem('egoa_notifications');
    setNotifications(savedNotifications ? JSON.parse(savedNotifications) : []);
  }, []);

  const addNotification = (targetUserId, message, type = 'info', link = null, title = 'New Notification') => {
    const newNotification = {
      id: generateId(),
      userId: targetUserId,
      title,
      message,
      type,
      link,
      timestamp: new Date().toISOString(),
      read: false,
    };
    setNotifications(prev => {
      const updatedNotifications = [newNotification, ...prev];
      saveToStorage(updatedNotifications);
      return updatedNotifications;
    });
  };

  const markAsRead = (notificationId) => {
    setNotifications(prev => {
      const updatedNotifications = prev.map(n => n.id === notificationId ? { ...n, read: true } : n);
      saveToStorage(updatedNotifications);
      return updatedNotifications;
    });
  };

  const markAllAsRead = (targetUserId) => {
    setNotifications(prev => {
      const updatedNotifications = prev.map(n => n.userId === targetUserId ? { ...n, read: true } : n);
      saveToStorage(updatedNotifications);
      return updatedNotifications;
    });
  };

  const getNotificationsForUser = (targetUserId) => {
    return notifications.filter(n => n.userId === targetUserId).sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
  };

  const getUnreadCountForUser = (targetUserId) => {
    return notifications.filter(n => n.userId === targetUserId && !n.read).length;
  };
  
  const clearNotificationsForUser = (targetUserId) => {
    setNotifications(prev => {
        const updatedNotifications = prev.filter(n => n.userId !== targetUserId);
        saveToStorage(updatedNotifications);
        return updatedNotifications;
    });
  };

  const clearAllNotifications = () => {
    setNotifications([]);
    saveToStorage([]);
  };


  const value = {
    notifications,
    addNotification,
    markAsRead,
    markAllAsRead,
    getNotificationsForUser,
    getUnreadCountForUser,
    clearNotificationsForUser,
    clearAllNotifications
  };

  return <NotificationContext.Provider value={value}>{children}</NotificationContext.Provider>;
}
