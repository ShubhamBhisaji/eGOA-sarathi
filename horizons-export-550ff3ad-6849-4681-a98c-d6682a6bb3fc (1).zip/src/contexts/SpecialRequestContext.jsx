import React, { createContext, useState, useEffect } from 'react';

export const SpecialRequestContext = createContext(null);

const generateId = (prefix = 'EGS') => {
  const timestamp = Date.now().toString().slice(-6);
  const random = Math.floor(Math.random() * 1000).toString().padStart(3, '0');
  return `${prefix}${timestamp}${random}`;
};

export function SpecialRequestProvider({ children }) {
  const [specialRequests, setSpecialRequests] = useState([]);

  const saveToStorage = (key, data) => {
    localStorage.setItem(key, JSON.stringify(data));
  };

  useEffect(() => {
    const savedSpecialRequests = localStorage.getItem('egoa_special_requests');
    setSpecialRequests(savedSpecialRequests ? JSON.parse(savedSpecialRequests) : []);
  }, []);

  const createSpecialRequest = (vleId, requestType, serviceName, description, customerDetails, documents) => {
    const request = {
      id: generateId('SR'),
      vleId,
      requestType, 
      serviceName: requestType === 'special_service' ? serviceName : null,
      description,
      customerDetails: requestType === 'special_service' ? customerDetails : null,
      documents: documents || [], 
      status: 'pending_admin_review',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      adminRemarks: null,
      history: [{ status: 'pending_admin_review', timestamp: new Date().toISOString(), remarks: 'Request submitted by VLE.' }]
    };
    const newSpecialRequests = [...specialRequests, request];
    setSpecialRequests(newSpecialRequests);
    saveToStorage('egoa_special_requests', newSpecialRequests);
    return request;
  };

  const updateSpecialRequestStatus = (requestId, status, adminRemarks, newDocuments = []) => {
    const newSpecialRequests = specialRequests.map(sr => 
      sr.id === requestId ? {
        ...sr,
        status,
        adminRemarks,
        documents: [...(sr.documents || []), ...newDocuments.map(d => ({...d, uploadedBy: 'admin'}))],
        updatedAt: new Date().toISOString(),
        history: [...(sr.history || []), { status, timestamp: new Date().toISOString(), remarks: adminRemarks || `Status updated to ${status}. ${newDocuments.length > 0 ? `Added ${newDocuments.length} document(s).` : ''}`.trim() }]
      } : sr
    );
    setSpecialRequests(newSpecialRequests);
    saveToStorage('egoa_special_requests', newSpecialRequests);
  };
  
  const addDocumentsToSpecialRequest = (requestId, documents, remarks = "Documents added by Admin.") => {
    const newSpecialRequests = specialRequests.map(sr => {
      if (sr.id === requestId) {
        return {
          ...sr,
          documents: [...(sr.documents || []), ...documents.map(d => ({...d, uploadedBy: 'admin'}))],
          updatedAt: new Date().toISOString(),
          history: [...(sr.history || []), { status: sr.status, timestamp: new Date().toISOString(), remarks: remarks }],
        };
      }
      return sr;
    });
    setSpecialRequests(newSpecialRequests);
    saveToStorage('egoa_special_requests', newSpecialRequests);
  };

  const clearSpecialRequests = () => {
    setSpecialRequests([]);
    saveToStorage('egoa_special_requests', []);
  };

  const value = {
    specialRequests,
    createSpecialRequest,
    updateSpecialRequestStatus,
    addDocumentsToSpecialRequest,
    clearSpecialRequests
  };

  return <SpecialRequestContext.Provider value={value}>{children}</SpecialRequestContext.Provider>;
}
