import React, { createContext, useState, useEffect, useContext } from 'react';
import { useAuth } from '@/hooks/useAuth.jsx';

export const UserContext = createContext(null);

const DEMO_CUSTOMERS_FOR_MANAGEMENT = [
  {
    id: 'customer-1',
    email: 'customer1@gmail.com',
    name: 'Ramesh Patel',
    phone: '+91 9876543210',
    address: '123, MG Road, Panaji, Goa',
    joinedDate: '2024-01-15T10:00:00.000Z'
  },
  {
    id: 'customer-2',
    email: 'customer2@gmail.com',
    name: 'Meera Singh',
    phone: '+91 9876543211',
    address: '456, ABC Colony, Margao, Goa',
    joinedDate: '2024-02-20T11:30:00.000Z'
  }
];


export function UserProvider({ children }) {
  const [customers, setCustomers] = useState([]);
  const { DEMO_USERS, updateUserInStorage } = useAuth(); 

  const saveToStorage = (key, data) => {
    localStorage.setItem(key, JSON.stringify(data));
  };

  useEffect(() => {
    const savedCustomers = localStorage.getItem('egoa_customers_management');
    if (savedCustomers) {
      setCustomers(JSON.parse(savedCustomers));
    } else {
      const initialCustomers = DEMO_USERS.filter(u => u.role === 'customer').map(u => ({
        id: u.id,
        email: u.email,
        name: u.name,
        phone: u.phone,
        address: u.address,
        joinedDate: u.joinedDate || new Date().toISOString() 
      }));
      setCustomers(initialCustomers);
      saveToStorage('egoa_customers_management', initialCustomers);
    }
  }, [DEMO_USERS]);

  const getCustomers = () => {
    return customers;
  };

  const getVLEs = () => {
    return DEMO_USERS.filter(u => u.role === 'vle');
  };
  
  const getUserById = (userId) => {
    return DEMO_USERS.find(u => u.id === userId);
  };

  const updateUserDetails = (userId, updatedDetails) => {
    const success = updateUserInStorage(userId, updatedDetails);
    if (success && updatedDetails.role === 'customer') {
        setCustomers(prevCustomers => 
            prevCustomers.map(c => c.id === userId ? { ...c, ...updatedDetails } : c)
        );
    }
    return success;
  };

  const addBankAccount = (userId, bankAccountDetails) => {
    const user = getUserById(userId);
    if (user) {
      const updatedBankAccounts = [...(user.bankAccounts || []), bankAccountDetails];
      return updateUserDetails(userId, { bankAccounts: updatedBankAccounts });
    }
    return false;
  };

  const removeBankAccount = (userId, accountNumber) => {
    const user = getUserById(userId);
    if (user && user.bankAccounts) {
      const updatedBankAccounts = user.bankAccounts.filter(acc => acc.accountNumber !== accountNumber);
      return updateUserDetails(userId, { bankAccounts: updatedBankAccounts });
    }
    return false;
  };


  const clearCustomers = () => {
    setCustomers([]);
    saveToStorage('egoa_customers_management', []);
  };

  const value = {
    getCustomers,
    getVLEs,
    getUserById,
    updateUserDetails,
    addBankAccount,
    removeBankAccount,
    clearCustomers
  };

  return <UserContext.Provider value={value}>{children}</UserContext.Provider>;
}