import React, { createContext, useState, useEffect } from 'react';

export const ComplaintContext = createContext(null);

const generateId = (prefix = 'EGS') => {
  const timestamp = Date.now().toString().slice(-6);
  const random = Math.floor(Math.random() * 1000).toString().padStart(3, '0');
  return `${prefix}${timestamp}${random}`;
};

export function ComplaintProvider({ children }) {
  const [complaints, setComplaints] = useState([]);

  const saveToStorage = (key, data) => {
    localStorage.setItem(key, JSON.stringify(data));
  };

  useEffect(() => {
    const savedComplaints = localStorage.getItem('egoa_complaints');
    setComplaints(savedComplaints ? JSON.parse(savedComplaints) : []);
  }, []);

  const createComplaint = (bookingId, customerId, subject, description, rating, type = 'complaint') => {
    const complaint = {
      id: `${type.toUpperCase()}-${generateId()}`,
      bookingId,
      customerId,
      subject,
      description,
      rating,
      type, 
      status: 'open',
      createdAt: new Date().toISOString(),
      history: [{ status: 'open', timestamp: new Date().toISOString(), remarks: `${type.charAt(0).toUpperCase() + type.slice(1)} registered.` }]
    };
    const newComplaints = [...complaints, complaint];
    setComplaints(newComplaints);
    saveToStorage('egoa_complaints', newComplaints);
    return complaint;
  };

  const resolveComplaint = (complaintId, remarks, documents) => {
    const newComplaints = complaints.map(c => 
      c.id === complaintId ? { 
        ...c, 
        status: 'resolved', 
        resolutionDetails: { remarks, documents, resolvedAt: new Date().toISOString() },
        history: [...(c.history || []), { status: 'resolved', timestamp: new Date().toISOString(), remarks: `Resolved: ${remarks}` }]
      } : c
    );
    setComplaints(newComplaints);
    saveToStorage('egoa_complaints', newComplaints);
  };

  const clearComplaints = () => {
    setComplaints([]);
    saveToStorage('egoa_complaints', []);
  };

  const value = {
    complaints,
    createComplaint,
    resolveComplaint,
    clearComplaints
  };

  return <ComplaintContext.Provider value={value}>{children}</ComplaintContext.Provider>;
}
