
import React from 'react';
import { BookingProvider } from './BookingContext';
import { LeadProvider } from './LeadContext';
import { TaskProvider } from './TaskContext';
import { UserProvider } from './UserContext';
import { ComplaintProvider } from './ComplaintContext';
import { SpecialRequestProvider } from './SpecialRequestContext';
import { WalletProvider } from './WalletContext';
import { NotificationProvider } from './NotificationContext'; 
import { DataContext } from '@/hooks/useData'; 
import { useContext } from 'react';


export function DataProvider({ children }) {
  return (
    <UserProvider>
      <WalletProvider>
        <NotificationProvider>
          <TaskProvider>
            <BookingProvider>
              <LeadProvider>
                  <ComplaintProvider>
                    <SpecialRequestProvider>
                      {children}
                    </SpecialRequestProvider>
                  </ComplaintProvider>
              </LeadProvider>
            </BookingProvider>
          </TaskProvider>
        </NotificationProvider>
      </WalletProvider>
    </UserProvider>
  );
}

export function useCombinedData() {
  const bookingContext = useContext(DataContext.BookingContext);
  const leadContext = useContext(DataContext.LeadContext);
  const taskContext = useContext(DataContext.TaskContext);
  const userContext = useContext(DataContext.UserContext);
  const complaintContext = useContext(DataContext.ComplaintContext);
  const specialRequestContext = useContext(DataContext.SpecialRequestContext);
  const walletContext = useContext(DataContext.WalletContext);
  const notificationContext = useContext(DataContext.NotificationContext);


  const clearAllData = () => {
    if (bookingContext) bookingContext.clearBookings();
    if (leadContext) leadContext.clearLeads();
    if (taskContext) taskContext.clearTasks();
    if (userContext) userContext.clearCustomers();
    if (complaintContext) complaintContext.clearComplaints();
    if (specialRequestContext) specialRequestContext.clearSpecialRequests();
    if (notificationContext) notificationContext.clearAllNotifications();
    
  };
  
  return {
    services: bookingContext ? bookingContext.services : [],
    bookings: bookingContext ? bookingContext.bookings : [],
    createBooking: bookingContext ? bookingContext.createBooking : () => {},
    addDocumentsToBooking: bookingContext ? bookingContext.addDocumentsToBooking : () => {},
    
    leads: leadContext ? leadContext.leads : [],
    createLead: leadContext ? leadContext.createLead : () => {},
    addDocumentsToLead: leadContext ? leadContext.addDocumentsToLead : () => {},

    tasks: taskContext ? taskContext.tasks : [],
    assignTask: taskContext ? taskContext.assignTask : () => {},
    updateTask: taskContext ? taskContext.updateTask : () => {},
    reassignTask: taskContext ? taskContext.reassignTask : () => {},
    addDocumentsToTask: taskContext ? taskContext.addDocumentsToTask : () => {},
    approveCommission: taskContext ? taskContext.approveCommission : () => {},
    rejectCommission: taskContext ? taskContext.rejectCommission : () => {},
    
    getCustomers: userContext ? userContext.getCustomers : () => [],
    getVLEs: userContext ? userContext.getVLEs : () => [],
    getUserById: userContext ? userContext.getUserById : () => null,
    updateUserDetails: userContext ? userContext.updateUserDetails : () => false,
    addBankAccount: userContext ? userContext.addBankAccount : () => false,
    removeBankAccount: userContext ? userContext.removeBankAccount : () => false,

    complaints: complaintContext ? complaintContext.complaints : [],
    createComplaint: complaintContext ? complaintContext.createComplaint : () => {},
    resolveComplaint: complaintContext ? complaintContext.resolveComplaint : () => {},
    
    specialRequests: specialRequestContext ? specialRequestContext.specialRequests : [],
    createSpecialRequest: specialRequestContext ? specialRequestContext.createSpecialRequest : () => {},
    updateSpecialRequestStatus: specialRequestContext ? specialRequestContext.updateSpecialRequestStatus : () => {},
    addDocumentsToSpecialRequest: specialRequestContext ? specialRequestContext.addDocumentsToSpecialRequest : () => {},

    addDemoMoney: walletContext ? walletContext.addDemoMoney : () => ({success: false, error: "Wallet not available"}),
    withdrawDemoMoney: walletContext ? walletContext.withdrawDemoMoney : () => ({success: false, error: "Wallet not available"}),
    debitUserWallet: walletContext ? walletContext.debitUserWallet : () => false,
    creditUserWallet: walletContext ? walletContext.creditUserWallet : () => false,
    processTaskCompletionPayouts: walletContext ? walletContext.processTaskCompletionPayouts : () => ({success: false, error: "Wallet not available"}),
    issueRefundToCustomer: walletContext ? walletContext.issueRefundToCustomer : () => ({success: false, error: "Wallet not available"}),
    checkBalance: walletContext ? walletContext.checkBalance : () => false,
    getWalletDetails: walletContext ? walletContext.getWalletDetails : () => null,
    platformCommission: walletContext ? walletContext.platformCommission : 0,

    notifications: notificationContext ? notificationContext.notifications : [],
    addNotification: notificationContext ? notificationContext.addNotification : () => {},
    markAsRead: notificationContext ? notificationContext.markAsRead : () => {},
    markAllAsRead: notificationContext ? notificationContext.markAllAsRead : () => {},
    getNotificationsForUser: notificationContext ? notificationContext.getNotificationsForUser : () => [],
    getUnreadCountForUser: notificationContext ? notificationContext.getUnreadCountForUser : () => 0,
    clearNotificationsForUser: notificationContext ? notificationContext.clearNotificationsForUser : () => {},


    clearAllData,
  };
}
