
import React, { createContext, useState, useEffect, useContext } from 'react';
import { BookingContext } from '@/contexts/BookingContext';
import { TaskContext } from '@/contexts/TaskContext';
import { WalletContext } from '@/contexts/WalletContext'; 
import { NotificationContext } from '@/contexts/NotificationContext';


export const LeadContext = createContext(null);

const generateId = (prefix = 'EGS') => {
  const timestamp = Date.now().toString().slice(-6);
  const random = Math.floor(Math.random() * 1000).toString().padStart(3, '0');
  return `${prefix}${timestamp}${random}`;
};

export function LeadProvider({ children }) {
  const [leads, setLeads] = useState([]);
  const bookingContext = useContext(BookingContext);
  const taskContext = useContext(TaskContext);
  const walletContext = useContext(WalletContext); 
  const notificationContext = useContext(NotificationContext);


  const saveToStorage = (key, data) => {
    localStorage.setItem(key, JSON.stringify(data));
  };

  useEffect(() => {
    const savedLeads = localStorage.getItem('egoa_leads');
    setLeads(savedLeads ? JSON.parse(savedLeads) : []);
  }, []);

  const createLead = (serviceId, vleId, customerName, customerPhone, documents) => {
    if (!taskContext || !walletContext || !notificationContext || !bookingContext) {
      console.error("Required contexts not available in LeadProvider");
      return { success: false, error: "Context not available." };
    }
    const service = bookingContext.services.find(s => s.id === serviceId);
    if (!service) {
        console.error("Service not found for ID:", serviceId);
        return { success: false, error: "Service not found." };
    }

    const serviceFee = service.fee;
    
    const canAfford = walletContext.checkBalance(vleId, serviceFee);
    if (!canAfford) {
      return { success: false, error: `Insufficient wallet balance. Service fee of ₹${serviceFee.toFixed(2)} required.` };
    }

    const lead = {
      id: generateId('LED'),
      serviceId,
      serviceName: service.name,
      vleId, 
      customerName,
      customerPhone,
      documents, 
      status: 'pending', 
      createdAt: new Date().toISOString(),
      fee: service.fee, 
      serviceFeePaidByGenerator: serviceFee,
      type: 'lead',
      history: [{ status: 'pending', timestamp: new Date().toISOString(), remarks: `Lead created. Service fee ₹${serviceFee.toFixed(2)} deducted.` }]
    };

    walletContext.debitUserWallet(vleId, serviceFee, `Lead generation: ${service.name} (Lead ID: ${lead.id})`);
    
    const newLeads = [...leads, lead];
    setLeads(newLeads);
    saveToStorage('egoa_leads', newLeads);
    
    taskContext.createTaskFromLead(lead); 
    return { success: true, lead };
  };

  const updateLeadStatusAndHistory = (leadId, newStatus, remarks) => {
    setLeads(prevLeads => {
      const newLeads = prevLeads.map(l => {
        if (l.id === leadId) {
          if (l.status !== newStatus && notificationContext) {
             notificationContext.addNotification(l.vleId, `Status of your generated lead for "${l.serviceName}" (Customer: ${l.customerName}) updated to ${newStatus.replace(/_/g, ' ')}. Remark: ${remarks}`, 'info', `/vle-dashboard?tab=my-leads&leadId=${l.id}`, 'Lead Status Update');
          }
          return {
            ...l,
            status: newStatus,
            history: [...(l.history || []), { status: newStatus, timestamp: new Date().toISOString(), remarks }]
          };
        }
        return l;
      });
      saveToStorage('egoa_leads', newLeads);
      return newLeads;
    });
  };
  
  const addDocumentsToLead = (leadId, newDocs, remarks, newStatus) => {
    setLeads(prevLeads => {
        const updatedLeads = prevLeads.map(l => {
            if (l.id === leadId) {
                const updatedDocsList = [...(l.documents || []), ...newDocs];
                const historyEntry = { status: newStatus || l.status, timestamp: new Date().toISOString(), remarks: remarks || `Added ${newDocs.length} new document(s).` };
                if (notificationContext) {
                   notificationContext.addNotification(l.vleId, `Documents added to your generated lead for "${l.serviceName}". Remark: ${remarks}`, 'info', `/vle-dashboard?tab=my-leads&leadId=${l.id}`, 'Lead Documents Updated');
                }
                return { ...l, documents: updatedDocsList, status: newStatus || l.status, history: [...(l.history || []), historyEntry] };
            }
            return l;
        });
        saveToStorage('egoa_leads', updatedLeads);
        return updatedLeads;
    });
  };

  const clearLeads = () => {
    setLeads([]);
    saveToStorage('egoa_leads', []);
  };

  const value = {
    leads,
    createLead,
    updateLeadStatusAndHistory,
    addDocumentsToLead,
    clearLeads
  };

  return <LeadContext.Provider value={value}>{children}</LeadContext.Provider>;
}
