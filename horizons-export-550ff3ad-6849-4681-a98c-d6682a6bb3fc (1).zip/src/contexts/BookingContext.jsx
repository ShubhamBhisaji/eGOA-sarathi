
import React, { createContext, useState, useEffect, useContext } from 'react';
import { useAuth } from '@/hooks/useAuth.jsx';
import { TaskContext } from '@/contexts/TaskContext'; 
import { WalletContext } from '@/contexts/WalletContext';
import { NotificationContext } from '@/contexts/NotificationContext';

export const BookingContext = createContext(null);

const INITIAL_SERVICES = [
  { id: 'birth-cert', name: 'Birth Certificate', category: 'Civil', fee: 50 },
  { id: 'death-cert', name: 'Death Certificate', category: 'Civil', fee: 50 },
  { id: 'income-cert', name: 'Income Certificate', category: 'Revenue', fee: 100 },
  { id: 'caste-cert', name: 'Caste Certificate', category: 'Social Welfare', fee: 75 },
  { id: 'domicile-cert', name: 'Domicile Certificate', category: 'Revenue', fee: 100 },
  { id: 'ration-card', name: 'Ration Card', category: 'Food & Supplies', fee: 25 },
  { id: 'voter-id', name: 'Voter ID Card', category: 'Election', fee: 0 },
  { id: 'pan-card', name: 'PAN Card', category: 'Income Tax', fee: 110 }
];

const generateId = (prefix = 'EGS') => {
  const timestamp = Date.now().toString().slice(-6);
  const random = Math.floor(Math.random() * 1000).toString().padStart(3, '0');
  return `${prefix}${timestamp}${random}`;
};

export function BookingProvider({ children }) {
  const [bookings, setBookings] = useState([]);
  const [services, setServices] = useState([]);
  const { user } = useAuth();
  const taskContext = useContext(TaskContext);
  const walletContext = useContext(WalletContext);
  const notificationContext = useContext(NotificationContext);


  const saveToStorage = (key, data) => {
    localStorage.setItem(key, JSON.stringify(data));
  };

  useEffect(() => {
    const savedBookings = localStorage.getItem('egoa_bookings');
    setBookings(savedBookings ? JSON.parse(savedBookings) : []);
    
    const savedServices = localStorage.getItem('egoa_services');
    setServices(savedServices ? JSON.parse(savedServices) : INITIAL_SERVICES);
  }, []);

  const createBooking = (serviceId, customerId, documents, customerDetails) => {
    if (!walletContext || !taskContext || !notificationContext) {
      console.error("Required contexts not available in BookingProvider");
      return { success: false, error: "Context initialization error." }; 
    }
    const service = services.find(s => s.id === serviceId);
    if (!service) {
        console.error("Service not found for ID:", serviceId);
        return { success: false, error: "Service not found." };
    }

    const fee = service.fee;
    const canAfford = walletContext.checkBalance(customerId, fee);

    if (!canAfford) {
      return { success: false, error: "Insufficient wallet balance. Please add funds." };
    }

    const booking = {
      id: generateId('BOK'),
      serviceId,
      serviceName: service.name,
      customerId,
      customerDetails,
      documents, 
      status: 'pending', 
      createdAt: new Date().toISOString(),
      fee: service.fee,
      type: 'booking',
      history: [{ status: 'pending', timestamp: new Date().toISOString(), remarks: 'Booking created and fee deducted from wallet.' }]
    };

    walletContext.debitUserWallet(customerId, fee, `Service booking: ${service.name} (ID: ${booking.id})`);
    
    const newBookings = [...bookings, booking];
    setBookings(newBookings);
    saveToStorage('egoa_bookings', newBookings);
    
    taskContext.createTaskFromBooking(booking);

    return { success: true, booking };
  };
  
  const updateBookingStatusAndHistory = (bookingId, newStatus, remarks) => {
    setBookings(prevBookings => {
      const newBookings = prevBookings.map(b => {
        if (b.id === bookingId) {
          if (b.status !== newStatus && notificationContext) {
            notificationContext.addNotification(b.customerId, `Status of your booking for "${b.serviceName}" updated to ${newStatus.replace(/_/g, ' ')}. Remark: ${remarks}`, 'info', `/customer-dashboard?tab=my-bookings&bookingId=${b.id}`, 'Booking Status Update');
          }
          return {
            ...b,
            status: newStatus,
            history: [...(b.history || []), { status: newStatus, timestamp: new Date().toISOString(), remarks }]
          };
        }
        return b;
      });
      saveToStorage('egoa_bookings', newBookings);
      return newBookings;
    });
  };
  
  const addDocumentsToBooking = (bookingId, newDocs, remarks, newStatus) => {
    setBookings(prevBookings => {
        const updatedBookings = prevBookings.map(b => {
            if (b.id === bookingId) {
                const updatedDocsList = [...(b.documents || []), ...newDocs];
                const historyEntry = { status: newStatus || b.status, timestamp: new Date().toISOString(), remarks: remarks || `Added ${newDocs.length} new document(s).` };
                if (notificationContext) {
                   notificationContext.addNotification(b.customerId, `Documents added to your booking for "${b.serviceName}". Remark: ${remarks}`, 'info', `/customer-dashboard?tab=my-bookings&bookingId=${b.id}`, 'Documents Updated');
                }
                return { ...b, documents: updatedDocsList, status: newStatus || b.status, history: [...(b.history || []), historyEntry] };
            }
            return b;
        });
        saveToStorage('egoa_bookings', updatedBookings);
        return updatedBookings;
    });
  };

  const addService = (name, category, fee) => {
    const newService = {
        id: generateId('SRV'),
        name,
        category,
        fee
    };
    const updatedServices = [...services, newService];
    setServices(updatedServices);
    saveToStorage('egoa_services', updatedServices);
    return { success: true, service: newService };
  };

  const updateService = (serviceId, name, category, fee) => {
    const updatedServices = services.map(s => 
        s.id === serviceId ? { ...s, name, category, fee } : s
    );
    setServices(updatedServices);
    saveToStorage('egoa_services', updatedServices);
    return { success: true };
  };

  const removeService = (serviceId) => {
    const activeBookingsForService = bookings.some(b => b.serviceId === serviceId && b.status !== 'completed' && b.status !== 'rejected');
    // Consider checking leads and tasks too if services are deeply integrated there
    if (activeBookingsForService) {
        return { success: false, error: "Cannot remove service with active bookings. Please resolve them first." };
    }
    const updatedServices = services.filter(s => s.id !== serviceId);
    setServices(updatedServices);
    saveToStorage('egoa_services', updatedServices);
    return { success: true };
  };

  const clearBookings = () => {
    setBookings([]);
    saveToStorage('egoa_bookings', []);
  };

  const value = {
    services,
    bookings,
    createBooking,
    updateBookingStatusAndHistory,
    addDocumentsToBooking,
    addService,
    updateService,
    removeService,
    clearBookings
  };

  return <BookingContext.Provider value={value}>{children}</BookingContext.Provider>;
}
