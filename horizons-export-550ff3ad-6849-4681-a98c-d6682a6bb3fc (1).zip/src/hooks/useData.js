
import { useContext } from 'react';
import { BookingContext } from '@/contexts/BookingContext';
import { LeadContext } from '@/contexts/LeadContext';
import { TaskContext } from '@/contexts/TaskContext';
import { UserContext } from '@/contexts/UserContext';
import { ComplaintContext } from '@/contexts/ComplaintContext';
import { SpecialRequestContext } from '@/contexts/SpecialRequestContext';
import { WalletContext } from '@/contexts/WalletContext';
import { NotificationContext } from '@/contexts/NotificationContext';

export const DataContext = {
    BookingContext,
    LeadContext,
    TaskContext,
    UserContext,
    ComplaintContext,
    SpecialRequestContext,
    WalletContext,
    NotificationContext
};

export function useData() {
  const bookingContext = useContext(BookingContext);
  const leadContext = useContext(LeadContext);
  const taskContext = useContext(TaskContext);
  const userContext = useContext(UserContext);
  const complaintContext = useContext(ComplaintContext);
  const specialRequestContext = useContext(SpecialRequestContext);
  const walletContext = useContext(WalletContext);
  const notificationContext = useContext(NotificationContext);

  const clearAllData = () => {
    if (bookingContext) bookingContext.clearBookings();
    if (leadContext) leadContext.clearLeads();
    if (taskContext) taskContext.clearTasks();
    if (userContext) userContext.clearCustomers(); 
    if (complaintContext) complaintContext.clearComplaints();
    if (specialRequestContext) specialRequestContext.clearSpecialRequests();
    if (notificationContext) notificationContext.clearAllNotifications();
    
    localStorage.removeItem('egoa_platform_commission'); 
  };
  
  return {
    services: bookingContext ? bookingContext.services : [],
    addService: bookingContext ? bookingContext.addService : () => ({success: false, error: "Service context not available"}),
    updateService: bookingContext ? bookingContext.updateService : () => ({success: false, error: "Service context not available"}),
    removeService: bookingContext ? bookingContext.removeService : () => ({success: false, error: "Service context not available"}),
    
    bookings: bookingContext ? bookingContext.bookings : [],
    createBooking: bookingContext ? bookingContext.createBooking : () => ({success: false, error: "Booking context not available"}),
    addDocumentsToBooking: bookingContext ? bookingContext.addDocumentsToBooking : () => {},
    
    leads: leadContext ? leadContext.leads : [],
    createLead: leadContext ? leadContext.createLead : () => null,
    addDocumentsToLead: leadContext ? leadContext.addDocumentsToLead : () => {},

    tasks: taskContext ? taskContext.tasks : [],
    assignTask: taskContext ? taskContext.assignTask : () => null,
    updateTask: taskContext ? taskContext.updateTask : () => null,
    reassignTask: taskContext ? taskContext.reassignTask : () => {},
    addDocumentsToTask: taskContext ? taskContext.addDocumentsToTask : () => null,
    approveCommission: taskContext ? taskContext.approveCommission : () => {},
    rejectCommission: taskContext ? taskContext.rejectCommission : () => {},
    
    getCustomers: userContext ? userContext.getCustomers : () => [],
    getVLEs: userContext ? userContext.getVLEs : () => [],
    getUserById: userContext ? userContext.getUserById : () => null,
    updateUserDetails: userContext ? userContext.updateUserDetails : () => false,
    addBankAccount: userContext ? userContext.addBankAccount : () => false,
    removeBankAccount: userContext ? userContext.removeBankAccount : () => false,

    complaints: complaintContext ? complaintContext.complaints : [],
    createComplaint: complaintContext ? complaintContext.createComplaint : () => null,
    resolveComplaint: complaintContext ? complaintContext.resolveComplaint : () => {},
    
    specialRequests: specialRequestContext ? specialRequestContext.specialRequests : [],
    createSpecialRequest: specialRequestContext ? specialRequestContext.createSpecialRequest : () => null,
    updateSpecialRequestStatus: specialRequestContext ? specialRequestContext.updateSpecialRequestStatus : () => {},
    addDocumentsToSpecialRequest: specialRequestContext ? specialRequestContext.addDocumentsToSpecialRequest : () => {},

    addDemoMoney: walletContext ? walletContext.addDemoMoney : () => ({success: false, error: "Wallet not available"}),
    withdrawDemoMoney: walletContext ? walletContext.withdrawDemoMoney : () => ({success: false, error: "Wallet not available"}),
    debitUserWallet: walletContext ? walletContext.debitUserWallet : () => false,
    creditUserWallet: walletContext ? walletContext.creditUserWallet : () => false,
    processTaskCompletionPayouts: walletContext ? walletContext.processTaskCompletionPayouts : () => ({success: false, error: "Wallet not available"}),
    issueRefundToCustomer: walletContext ? walletContext.issueRefundToCustomer : () => ({success: false, error: "Wallet not available"}),
    checkBalance: walletContext ? walletContext.checkBalance : () => false,
    getWalletDetails: walletContext ? walletContext.getWalletDetails : () => null,
    platformCommission: walletContext ? walletContext.platformCommission : 0,

    notifications: notificationContext ? notificationContext.notifications : [],
    addNotification: notificationContext ? notificationContext.addNotification : () => {},
    markAsRead: notificationContext ? notificationContext.markAsRead : () => {},
    markAllAsRead: notificationContext ? notificationContext.markAllAsRead : () => {},
    getNotificationsForUser: notificationContext ? notificationContext.getNotificationsForUser : () => [],
    getUnreadCountForUser: notificationContext ? notificationContext.getUnreadCountForUser : () => 0,
    clearNotificationsForUser: notificationContext ? notificationContext.clearNotificationsForUser : () => {},

    clearAllData,
  };
}
