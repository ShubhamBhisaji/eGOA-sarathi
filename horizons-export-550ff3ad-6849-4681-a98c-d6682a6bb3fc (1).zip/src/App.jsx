
import React from 'react';
import { useAuth } from '@/hooks/useAuth.jsx';
import { LoginForm } from '@/components/LoginForm';
import { CustomerDashboard } from '@/components/CustomerDashboard';
import { VLEDashboard } from '@/components/VLEDashboard';
import { AdminDashboard } from '@/components/AdminDashboard';
import { Toaster } from '@/components/ui/toaster';
import { motion, AnimatePresence } from 'framer-motion';
import { Routes, Route, Navigate, useLocation } from 'react-router-dom';

function ProtectedRoute({ children, isAuthenticated, role, targetRole }) {
  const location = useLocation();
  if (!isAuthenticated) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }
  if (role !== targetRole) {
    return <Navigate to="/login" replace />; 
  }
  return children;
}

function App() {
  const { user, login, quickLogin, signup, logout, loading, isAuthenticated } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-100 to-sky-100">
        <motion.div 
          className="w-20 h-20 border-4 border-t-transparent border-primary rounded-full"
          animate={{ rotate: 360 }}
          transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
        />
      </div>
    );
  }

  return (
    <>
      <AnimatePresence mode="wait">
        <Routes>
          <Route 
            path="/login" 
            element={
              !isAuthenticated ? (
                <motion.div
                  key="login"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 0.5 }}
                >
                  <LoginForm onLogin={login} onQuickLogin={quickLogin} onSignup={signup} />
                </motion.div>
              ) : (
                <Navigate to={
                  user.role === 'customer' ? "/customer-dashboard" :
                  user.role === 'vle' ? "/vle-dashboard" :
                  user.role === 'admin' ? "/admin-dashboard" : "/login"
                } replace />
              )
            } 
          />
          <Route 
            path="/customer-dashboard" 
            element={
              <ProtectedRoute isAuthenticated={isAuthenticated} role={user?.role} targetRole="customer">
                <CustomerDashboard user={user} onLogout={logout} />
              </ProtectedRoute>
            } 
          />
          <Route 
            path="/vle-dashboard" 
            element={
              <ProtectedRoute isAuthenticated={isAuthenticated} role={user?.role} targetRole="vle">
                <VLEDashboard user={user} onLogout={logout} />
              </ProtectedRoute>
            } 
          />
          <Route 
            path="/admin-dashboard" 
            element={
              <ProtectedRoute isAuthenticated={isAuthenticated} role={user?.role} targetRole="admin">
                <AdminDashboard user={user} onLogout={logout} />
              </ProtectedRoute>
            } 
          />
          <Route 
            path="*" 
            element={
              <Navigate to={
                isAuthenticated ? (
                  user.role === 'customer' ? "/customer-dashboard" :
                  user.role === 'vle' ? "/vle-dashboard" :
                  user.role === 'admin' ? "/admin-dashboard" : "/login"
                ) : "/login"
              } replace />
            } 
          />
        </Routes>
      </AnimatePresence>
      <Toaster />
    </>
  );
}

export default App;
