
import React, { useState, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogTrigger, DialogFooter, DialogClose } from '@/components/ui/dialog';
import { useToast } from '@/components/ui/use-toast';
import { Sparkles, HelpCircle, UserCircle, Phone, FileText as FileTextIcon, Edit3, CheckSquare, Upload, Trash2, Eye, Paperclip } from 'lucide-react';
import { motion } from 'framer-motion';
import { Badge } from '@/components/ui/badge';

const getStatusBadgeStyle = (status) => {
  switch (status) {
    case 'pending_admin_review':
      return 'status-pending';
    case 'admin_in_progress':
      return 'status-in-progress'; 
    case 'admin_resolved':
    case 'admin_information_provided':
      return 'status-completed'; 
    case 'admin_rejected':
      return 'status-rejected'; 
    default:
      return 'bg-slate-100 text-slate-700 border border-slate-300';
  }
};

const STATUS_OPTIONS = [
  { value: 'pending_admin_review', label: 'Pending Admin Review' },
  { value: 'admin_in_progress', label: 'In Progress' },
  { value: 'admin_resolved', label: 'Resolved (Service Provided)' },
  { value: 'admin_information_provided', label: 'Information Provided (Query Answered)' },
  { value: 'admin_rejected', label: 'Rejected' },
];

export function AdminSpecialRequests({ specialRequests, onUpdateStatus, vleUsers }) {
  const { toast } = useToast();
  const [selectedRequest, setSelectedRequest] = useState(null);
  const [newStatus, setNewStatus] = useState('');
  const [adminRemarks, setAdminRemarks] = useState('');
  const [isUpdateDialogOpen, setIsUpdateDialogOpen] = useState(false);
  const [adminDocuments, setAdminDocuments] = useState([]);
  const adminFileInputRef = useRef(null);

  const sortedRequests = [...specialRequests].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

  const handleOpenUpdateDialog = (request) => {
    setSelectedRequest(request);
    setNewStatus(request.status);
    setAdminRemarks(request.adminRemarks || '');
    setAdminDocuments([]); 
    setIsUpdateDialogOpen(true);
  };

  const handleAdminFileUpload = (e) => {
    const files = Array.from(e.target.files);
    if (files.length === 0) return;

    const newDocs = files.map(file => ({
      id: Date.now() + Math.random().toString(36).substring(2, 9),
      name: file.name,
      size: file.size,
      type: file.type,
      uploadedAt: new Date().toISOString(),
    }));
    setAdminDocuments(prevDocs => [...prevDocs, ...newDocs]);
    toast({ title: "Documents Added", description: `${files.length} document(s) ready for upload.` });
    if (adminFileInputRef.current) adminFileInputRef.current.value = "";
  };

  const removeAdminDocument = (docId) => {
    setAdminDocuments(prevDocs => prevDocs.filter(doc => doc.id !== docId));
    toast({ title: "Document Removed", description: "The selected document has been removed." });
  };

  const handleStatusUpdate = () => {
    if (!selectedRequest || !newStatus) {
      toast({ title: "Error", description: "No request selected or status missing.", variant: "destructive" });
      return;
    }
    if (!adminRemarks.trim() && (newStatus === 'admin_resolved' || newStatus === 'admin_information_provided' || newStatus === 'admin_rejected')) {
        toast({ title: "Remarks Required", description: "Please provide remarks for this status update.", variant: "destructive" });
        return;
    }
    const uploadedAdminDocs = adminDocuments.map(doc => ({ name: doc.name, size: doc.size, type: doc.type, uploadedAt: doc.uploadedAt, uploadedBy: 'admin'}));
    
    onUpdateStatus(selectedRequest.id, newStatus, adminRemarks, uploadedAdminDocs);
    
    toast({ title: "Status Updated", description: `Request ID ${selectedRequest.id} status updated.`, variant: "default" });
    setIsUpdateDialogOpen(false);
    setSelectedRequest(null);
    setAdminRemarks('');
    setAdminDocuments([]);
  };

  const getVleInfo = (vleId) => {
    const vle = vleUsers.find(v => v.id === vleId);
    return vle ? { name: vle.name, userId: vle.userId, center: vle.center } : { name: 'Unknown VLE', userId: 'N/A', center: 'N/A' };
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <Card className="shadow-xl border-sky-200 rounded-xl overflow-hidden">
        <CardHeader className="bg-gradient-to-r from-sky-50 to-blue-50 border-b border-sky-200 p-6">
          <CardTitle className="text-2xl font-poppins text-sky-800 flex items-center">
            <Sparkles className="mr-3 h-7 w-7 text-sky-600" /> Manage VLE Special Requests & Queries
          </CardTitle>
          <CardDescription className="font-inter text-sky-700">
            Review, manage, respond, and attach documents to special service requests and queries from VLEs.
          </CardDescription>
        </CardHeader>
        <CardContent className="p-0">
          {sortedRequests.length === 0 ? (
            <p className="p-10 text-center text-slate-500 font-inter text-lg">
              No special requests or queries from VLEs at the moment. All clear! ✨
            </p>
          ) : (
            <div className="divide-y divide-slate-100">
              {sortedRequests.map(req => {
                const vleInfo = getVleInfo(req.vleId);
                return (
                <motion.div 
                  key={req.id} 
                  className="p-4 md:p-6 hover:bg-sky-50/30 transition-colors duration-150"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.1 }}
                >
                  <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-3">
                    <div className="mb-2 md:mb-0">
                      <h4 className="font-semibold text-slate-800 text-md md:text-lg flex items-center">
                        {req.requestType === 'special_service' ? <Sparkles className="mr-2 h-5 w-5 text-yellow-500" /> : <HelpCircle className="mr-2 h-5 w-5 text-blue-500" />}
                        {req.requestType === 'special_service' ? (req.serviceName || 'Custom Service') : 'General Query'}
                      </h4>
                      <p className="text-xs text-slate-500">Request ID: {req.id}</p>
                      <p className="text-xs text-slate-500">VLE: {vleInfo.name} ({vleInfo.userId}) - {vleInfo.center}</p>
                    </div>
                    <Badge className={`${getStatusBadgeStyle(req.status)} min-w-[150px] justify-center text-xs`}>
                      {req.status.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
                    </Badge>
                  </div>
                  
                  <p className="text-sm text-slate-700 mb-3 leading-relaxed bg-slate-50 p-3 rounded-md border border-slate-200">{req.description}</p>

                  {req.customerDetails && req.customerDetails.name && (
                    <Card className="mb-3 p-3 bg-blue-50/50 border-blue-200 rounded-md text-xs">
                      <CardHeader className="p-0 pb-2"><CardTitle className="text-sm text-blue-700 font-semibold">Customer Info (Provided by VLE)</CardTitle></CardHeader>
                      <CardContent className="p-0 space-y-0.5 text-slate-700">
                        <p><UserCircle className="inline mr-1.5 h-3.5 w-3.5 text-blue-600" />Name: {req.customerDetails.name}</p>
                        {req.customerDetails.phone && <p><Phone className="inline mr-1.5 h-3.5 w-3.5 text-blue-600" />Phone: {req.customerDetails.phone}</p>}
                        {req.customerDetails.aadhaar && <p><FileTextIcon className="inline mr-1.5 h-3.5 w-3.5 text-blue-600" />Aadhaar: {req.customerDetails.aadhaar}</p>}
                      </CardContent>
                    </Card>
                  )}

                  {req.documents && req.documents.length > 0 && (
                    <div className="mb-3">
                        <Dialog>
                            <DialogTrigger asChild>
                                <Button variant="outline" size="sm" className="text-xs border-slate-300 hover:bg-slate-50">
                                    <Paperclip className="mr-2 h-3.5 w-3.5"/>View {req.documents.length} Attached Document(s)
                                </Button>
                            </DialogTrigger>
                            <DialogContent>
                                <DialogHeader><DialogTitle>Documents for Request: {req.id}</DialogTitle></DialogHeader>
                                <div className="py-2 max-h-72 overflow-y-auto text-xs">
                                    {req.documents.map((doc, idx) => (
                                        <div key={idx} className="p-2 border-b last:border-b-0 flex justify-between items-center">
                                            <span>{doc.name} ({(doc.size / 1024).toFixed(1)} KB)</span>
                                            <Badge variant="outline" className="text-xs">{doc.uploadedBy === 'admin' ? 'Admin' : 'VLE'}</Badge>
                                        </div>
                                    ))}
                                    {req.documents.length === 0 && <p className="text-center text-slate-500">No documents attached.</p>}
                                </div>
                            </DialogContent>
                        </Dialog>
                    </div>
                  )}
                  
                  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center text-xs text-slate-500">
                    <p>Submitted: {new Date(req.createdAt).toLocaleString()}</p>
                    <p>Last Updated by Admin: {new Date(req.updatedAt).toLocaleString()}</p>
                  </div>

                  {req.adminRemarks && (
                    <div className="mt-3 p-3 bg-green-50 rounded text-sm text-green-800 border border-green-200">
                      <strong>Admin Remarks:</strong> {req.adminRemarks}
                    </div>
                  )}

                  <div className="mt-4">
                    <Button variant="outline" size="sm" onClick={() => handleOpenUpdateDialog(req)} className="border-sky-500 text-sky-600 hover:bg-sky-50 hover:text-sky-700 shadow-sm hover:shadow-md transition-all">
                      <Edit3 className="mr-2 h-4 w-4" /> Update Status / Add Remarks / Attach Files
                    </Button>
                  </div>
                </motion.div>
              )})}
            </div>
          )}
        </CardContent>
      </Card>

      {selectedRequest && (
        <Dialog open={isUpdateDialogOpen} onOpenChange={(open) => { if(!open) setSelectedRequest(null); setIsUpdateDialogOpen(open); }}>
          <DialogContent className="sm:max-w-lg">
            <DialogHeader>
              <DialogTitle className="font-poppins text-xl text-slate-800">Update Request: {selectedRequest.id}</DialogTitle>
              <DialogDescription className="text-slate-600">
                VLE: {getVleInfo(selectedRequest.vleId).name} ({getVleInfo(selectedRequest.vleId).userId}) <br/>
                Request Type: {selectedRequest.requestType === 'special_service' ? (selectedRequest.serviceName || 'Custom Service') : 'General Query'}
              </DialogDescription>
            </DialogHeader>
            <div className="py-4 space-y-6 max-h-[70vh] overflow-y-auto pr-2">
              <div>
                <Label htmlFor="newStatus" className="font-medium text-slate-700">New Status</Label>
                <Select value={newStatus} onValueChange={setNewStatus}>
                  <SelectTrigger id="newStatus" className="w-full mt-1 rounded-md border-slate-300 focus:border-sky-500 focus:ring-sky-500">
                    <SelectValue placeholder="Select new status" />
                  </SelectTrigger>
                  <SelectContent>
                    {STATUS_OPTIONS.map(opt => (
                      <SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="adminRemarks" className="font-medium text-slate-700">Admin Remarks <span className="text-red-500">*</span></Label>
                <Textarea
                  id="adminRemarks"
                  value={adminRemarks}
                  onChange={(e) => setAdminRemarks(e.target.value)}
                  placeholder="Provide details about the resolution, information provided, or reason for rejection..."
                  className="mt-1 min-h-[100px] rounded-md border-slate-300 focus:border-sky-500 focus:ring-sky-500"
                  required
                />
                 <p className="text-xs text-slate-500 mt-1">Remarks are mandatory if changing status to Resolved, Info Provided, or Rejected.</p>
              </div>
              <div className="space-y-2">
                <Label htmlFor="admin-documents" className="font-medium text-slate-700">Attach Documents (Optional)</Label>
                <div className="border-2 border-dashed border-gray-300 rounded-lg p-4 text-center">
                    <Upload className="mx-auto h-8 w-8 text-gray-400" />
                    <Label htmlFor="admin-file-upload" className="cursor-pointer mt-2 block text-xs font-medium text-sky-600 hover:text-sky-500">Click to upload files</Label>
                    <Input id="admin-file-upload" type="file" multiple className="hidden" onChange={handleAdminFileUpload} ref={adminFileInputRef} accept=".pdf,.jpg,.jpeg,.png,.doc,.docx" />
                    <p className="mt-1 text-xs text-gray-500">PDF, JPG, PNG, DOC up to 10MB each</p>
                </div>
                {adminDocuments.length > 0 && (
                    <div className="space-y-1 pt-2">
                        <Label className="text-xs font-medium text-slate-600">Selected Documents ({adminDocuments.length})</Label>
                        {adminDocuments.map(doc => (
                        <div key={doc.id} className="flex items-center justify-between p-1.5 bg-gray-100 rounded text-xs">
                            <div className="flex items-center space-x-1 overflow-hidden">
                            <FileTextIcon className="h-3.5 w-3.5 text-gray-500 flex-shrink-0" />
                            <span className="font-medium truncate" title={doc.name}>{doc.name}</span>
                            </div>
                            <div className="flex items-center space-x-1 flex-shrink-0">
                            <span className="text-gray-500">{(doc.size / 1024 / 1024).toFixed(2)} MB</span>
                            <Button type="button" variant="ghost" size="sm" onClick={() => removeAdminDocument(doc.id)} className="p-0.5 h-auto">
                                <Trash2 className="h-3 w-3 text-red-500" />
                            </Button>
                            </div>
                        </div>))}
                    </div>
                )}
              </div>
            </div>
            <DialogFooter className="sm:justify-between pt-4 border-t">
              <DialogClose asChild>
                <Button variant="outline" className="w-full sm:w-auto">Cancel</Button>
              </DialogClose>
              <Button onClick={handleStatusUpdate} className="w-full sm:w-auto bg-sky-600 hover:bg-sky-700 text-white">
                <CheckSquare className="mr-2 h-4 w-4" /> Save Changes
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </motion.div>
  );
}
