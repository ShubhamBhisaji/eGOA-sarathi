
import React, { useState, useEffect } from 'react';
import { useToast } from '@/components/ui/use-toast';
import { useData } from '@/hooks/useData';
import { TabsContent } from '@/components/ui/tabs';
import { FileText, Clock, CheckCircle, XCircle, User, AlertTriangle, DollarSign, BarChart2 as CommissionIconLucide, Users as UsersIcon, UserCheck as UserCheckIcon, ListChecks as ServiceIcon } from 'lucide-react';
import { useAuth } from '@/hooks/useAuth.jsx';
import { motion } from 'framer-motion';
import { useLocation, useNavigate, useSearchParams } from 'react-router-dom';

import { AdminDashboardLayout } from '@/components/admin/AdminDashboardLayout';
import { AdminAssignTasks } from '@/components/admin/AdminAssignTasks';
import { AdminBookingsList } from '@/components/admin/AdminBookingsList';
import { AdminLeadsList } from '@/components/admin/AdminLeadsList';
import { AdminVLEManagement } from '@/components/admin/AdminVLEManagement';
import { AdminCustomerManagement } from '@/components/admin/AdminCustomerManagement';
import { AdminIssuesManagement } from '@/components/admin/AdminIssuesManagement';
import { AdminSpecialRequests } from '@/components/admin/AdminSpecialRequests';
import { AdminWalletManagement } from '@/components/admin/AdminWalletManagement';
import { AdminCommissionApproval } from '@/components/admin/AdminCommissionApproval';
import { AdminServiceManagement } from '@/components/admin/AdminServiceManagement';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';


const ADMIN_TABS_CONFIG = [
    { value: "assign-tasks", label: "Assign Tasks", icon: <FileText className="mr-2 h-4 w-4" /> },
    { value: "all-bookings", label: "All Bookings", icon: <FileText className="mr-2 h-4 w-4" /> },
    { value: "all-leads", label: "All Leads", icon: <UsersIcon className="mr-2 h-4 w-4" /> },
    { value: "vle-management", label: "VLEs", icon: <UserCheckIcon className="mr-2 h-4 w-4" /> },
    { value: "customer-management", label: "Customers", icon: <UsersIcon className="mr-2 h-4 w-4" /> },
    { value: "service-management", label: "Services", icon: <ServiceIcon className="mr-2 h-4 w-4" /> },
    { value: "issues-management", label: "Issues", icon: <AlertTriangle className="mr-2 h-4 w-4" /> },
    { value: "vle-special-requests", label: "VLE Requests", icon: <AlertTriangle className="mr-2 h-4 w-4" /> },
    { value: "accounting", label: "Wallet Mgmt", icon: <DollarSign className="mr-2 h-4 w-4" /> },
    { value: "commissions", label: "Commissions", icon: <CommissionIconLucide className="mr-2 h-4 w-4" /> },
];


const AdminComingSoonPlaceholder = ({ title, icon: Icon }) => (
  <Card className="shadow-lg border-dashed border-slate-300 rounded-xl h-full flex flex-col items-center justify-center text-center p-10 bg-slate-50/50">
    <CardHeader>
      <div className="mx-auto bg-slate-200 p-4 rounded-full mb-6">
        <Icon className="h-12 w-12 text-slate-500" />
      </div>
      <CardTitle className="text-2xl font-poppins text-slate-700">{title}</CardTitle>
    </CardHeader>
    <CardContent>
      <p className="text-slate-600 font-inter text-lg">
        This feature is under construction and will be available soon!
      </p>
      <p className="text-sm text-slate-500 mt-2">
        We're working hard to bring you an amazing experience. Stay tuned! 🚀
      </p>
    </CardContent>
  </Card>
);


export function AdminDashboard({ user, onLogout }) {
  const { 
    services, bookings, leads, tasks, assignTask, getCustomers, getVLEs,
    complaints, clearAllData, resolveComplaint, 
    specialRequests, updateSpecialRequestStatus, addNotification
  } = useData();
  const { toast } = useToast();
  const location = useLocation();
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();

  const VLES = getVLEs();

  const [allCustomers, setAllCustomers] = useState([]);
  const [activeTab, setActiveTab] = useState(searchParams.get('tab') || "assign-tasks");

  useEffect(() => {
    const tabFromUrl = searchParams.get('tab');
    const itemIdFromUrl = searchParams.get('taskId') || searchParams.get('bookingId') || searchParams.get('leadId') || searchParams.get('complaintId');

    if (tabFromUrl && ADMIN_TABS_CONFIG.find(t => t.value === tabFromUrl)) {
      setActiveTab(tabFromUrl);
    }
    
    if (itemIdFromUrl) {
      let elementIdPrefix = '';
      if (tabFromUrl === 'assign-tasks' || tabFromUrl === 'commissions') elementIdPrefix = 'task-';
      else if (tabFromUrl === 'all-bookings') elementIdPrefix = 'booking-';
      else if (tabFromUrl === 'all-leads') elementIdPrefix = 'lead-';
      else if (tabFromUrl === 'issues-management') elementIdPrefix = 'complaint-';
      
      if (elementIdPrefix) {
        const element = document.getElementById(`${elementIdPrefix}${itemIdFromUrl}`);
        if (element) {
          setTimeout(() => element.scrollIntoView({ behavior: 'smooth', block: 'center' }), 100);
        }
      }
    }
  }, [searchParams]);
  
  const handleTabChange = (newTab) => {
    setActiveTab(newTab);
    setSearchParams({ tab: newTab });
  };

  useEffect(() => {
    setAllCustomers(getCustomers());
  }, [getCustomers, activeTab]);

  const unassignedItems = [...bookings, ...leads].map(item => {
    const task = tasks.find(t => t.originalId === item.id && t.type === item.type);
    if (task && task.status === 'pending_assignment') {
      return { ...item, ...task, id: item.id, originalId: item.id, documents: task.documents.length > item.documents.length ? task.documents : item.documents };
    }
    if (!task && (item.status === 'pending' || item.status === 'rejected')) { 
        return item;
    }
    return null; 
  }).filter(Boolean).sort((a,b) => new Date(b.createdAt) - new Date(a.createdAt));


  const handleAssignTask = (item, vleId) => {
    const selectedVle = VLES.find(v => v.id === vleId);
    if (!selectedVle) {
        toast({ title: "Error: VLE Not Found", description: "The selected VLE could not be found. Please refresh and try again.", variant: "destructive" });
        return;
    }
    if(selectedVle.isAvailable === false){
        toast({ title: "VLE Unavailable", description: `${selectedVle.name} is currently marked as unavailable for new tasks.`, variant: "destructive" });
        return;
    }
    
    const taskForThisItem = tasks.find(t => t.originalId === item.id && t.type === item.type);

    if (item.type === 'lead' && item.vleId === vleId && (!taskForThisItem || taskForThisItem.status === 'pending_assignment')) { 
      toast({
        title: "Assignment Constraint",
        description: "A lead cannot be initially assigned to the VLE who generated it. This rule can be bypassed for re-assigning tasks if VLE rejected it.",
        variant: "destructive",
        duration: 7000,
      });
      return;
    }

    const assignedTask = assignTask(item.id, vleId, item.type);
    if (assignedTask) {
      toast({
        title: "Task Successfully Assigned",
        description: `Task for ${item.serviceName} has been assigned to VLE ${selectedVle.userId} (${selectedVle.name}).`,
        variant: 'default'
      });
      
      addNotification(selectedVle.id, `New task assigned: ${item.serviceName} for ${item.customerName || 'customer'}.`, 'info', `/vle-dashboard?tab=assigned-tasks&taskId=${assignedTask.id}`, 'New Task Assignment');
      
      if (item.customerId) {
        addNotification(item.customerId, `Your application for ${item.serviceName} has been assigned to a VLE.`, 'info', `/customer-dashboard?tab=my-bookings&bookingId=${item.id}`, 'Application Update');
      }
      if (item.type === 'lead' && item.vleId && item.vleId !== selectedVle.id) {
        addNotification(item.vleId, `Your generated lead for ${item.serviceName} (Customer: ${item.customerName}) has been assigned to VLE ${selectedVle.name}.`, 'info', `/vle-dashboard?tab=my-leads&leadId=${item.id}`, 'Lead Update');
      }
    } else {
       toast({ title: "Task Assignment Failed", description: "Could not assign the task. Please try again.", variant: "destructive" });
    }
  };

  const handleClearData = () => {
    clearAllData();
    toast({
      title: "All Data Cleared",
      description: "All application bookings, leads, tasks, and customer complaints have been cleared from the system.",
      variant: 'default'
    });
  };

  const getStatusIcon = (status) => {
    const iconMap = {
      pending: <Clock className="h-4 w-4 text-yellow-600" />,
      pending_assignment: <Clock className="h-4 w-4 text-orange-500" />,
      assigned: <User className="h-4 w-4 text-cyan-600" />,
      accepted: <CheckCircle className="h-4 w-4 text-sky-600" />,
      'additional-docs-vle': <FileText className="h-4 w-4 text-orange-600" />,
      'additional-docs-dept': <AlertTriangle className="h-4 w-4 text-amber-600" />,
      'ack-submitted': <FileText className="h-4 w-4 text-indigo-600" />,
      'in-progress': <Clock className="h-4 w-4 text-blue-600" />,
      completed: <CheckCircle className="h-4 w-4 text-green-600" />,
      pending_commission_approval: <DollarSign className="h-4 w-4 text-purple-600" />,
      commission_approved: <CheckCircle className="h-4 w-4 text-green-700" />,
      commission_rejected: <XCircle className="h-4 w-4 text-red-700" />,
      rejected: <XCircle className="h-4 w-4 text-red-600" />,
    };
    return iconMap[status] || <Clock className="h-4 w-4 text-slate-500" />;
  };
  
  const getStatusColor = (status) => {
    const colorMap = {
      pending: 'status-pending',
      pending_assignment: 'bg-orange-100 text-orange-700 border-orange-300',
      assigned: 'status-assigned',
      accepted: 'status-accepted',
      'additional-docs-vle': 'status-additional-docs-vle',
      'additional-docs-dept': 'status-additional-docs-dept',
      'ack-submitted': 'status-ack-submitted',
      'in-progress': 'status-in-progress',
      completed: 'status-completed',
      pending_commission_approval: 'bg-purple-100 text-purple-700 border-purple-300',
      commission_approved: 'bg-green-200 text-green-800 border-green-400',
      commission_rejected: 'bg-red-200 text-red-800 border-red-400',
      rejected: 'status-rejected',
    };
    return colorMap[status] || 'bg-slate-100 text-slate-700 border-slate-300';
  };

  const getLatestRemark = (item) => {
    const task = tasks.find(t => t.originalId === item.id && t.type === item.type);
    const source = task || item; 
    if (source.history && source.history.length > 0) {
      return source.history[source.history.length - 1].remarks || 'No remarks yet.';
    }
    return 'No remarks recorded yet.';
  };

  const stats = {
    totalBookings: bookings.length,
    totalLeads: leads.length,
    totalTasks: tasks.filter(t => t.status !== 'rejected' && t.status !== 'pending_assignment').length, 
    completedTasks: tasks.filter(t => t.status === 'commission_approved').length,
    pendingAssignments: unassignedItems.length,
    totalCustomers: allCustomers.length,
    openIssues: complaints.filter(c => c.status === 'open').length,
    pendingSpecialRequests: specialRequests.filter(sr => sr.status === 'pending_admin_review').length,
    totalServices: services.length,
  };

  const allBookingsWithDetails = bookings.map(b => {
    const task = tasks.find(t => t.originalId === b.id && t.type === 'booking');
    const vle = task && task.vleId ? VLES.find(v => v.id === task.vleId) : null;
    return { 
      ...b, 
      documents: task && task.documents.length > b.documents.length ? task.documents : b.documents,
      status: task ? task.status : b.status,
      assignedVleName: vle ? `${vle.name} (${vle.userId})` : 'N/A',
      history: task ? task.history : b.history
    };
  }).sort((a,b) => new Date(b.createdAt) - new Date(a.createdAt));

  const allLeadsWithDetails = leads.map(l => {
    const task = tasks.find(t => t.originalId === l.id && t.type === 'lead');
    const assignedVle = task && task.vleId ? VLES.find(v => v.id === task.vleId) : null;
    const generatedByVle = l.vleId ? VLES.find(v => v.id === l.vleId) : null;
    return { 
      ...l, 
      documents: task && task.documents.length > l.documents.length ? task.documents : l.documents,
      status: task ? task.status : l.status,
      assignedVleName: assignedVle ? `${assignedVle.name} (${assignedVle.userId})` : 'N/A',
      history: task ? task.history : l.history,
      generatedByVleName: generatedByVle ? generatedByVle.name : 'N/A'
    };
  }).sort((a,b) => new Date(b.createdAt) - new Date(a.createdAt));


  return (
    <AdminDashboardLayout 
        user={user} 
        onLogout={onLogout} 
        stats={stats} 
        activeTab={activeTab} 
        setActiveTab={handleTabChange}
        handleClearData={handleClearData}
        tabsConfig={ADMIN_TABS_CONFIG}
    >
      <motion.div 
        key={activeTab} 
        initial={{ opacity: 0, y: 10 }} 
        animate={{ opacity: 1, y: 0 }} 
        transition={{ duration: 0.3 }}
      >
        <TabsContent value="assign-tasks" className="space-y-6 mt-0">
            <AdminAssignTasks items={unassignedItems} onAssignTask={handleAssignTask} getLatestRemark={getLatestRemark} />
        </TabsContent>

        <TabsContent value="all-bookings" className="space-y-6 mt-0">
            <AdminBookingsList bookings={allBookingsWithDetails} getStatusIcon={getStatusIcon} getStatusColor={getStatusColor} getLatestRemark={getLatestRemark} />
        </TabsContent>

        <TabsContent value="all-leads" className="space-y-6 mt-0">
            <AdminLeadsList leads={allLeadsWithDetails} getStatusIcon={getStatusIcon} getStatusColor={getStatusColor} getLatestRemark={getLatestRemark} />
        </TabsContent>

        <TabsContent value="vle-management" className="space-y-6 mt-0">
            <AdminVLEManagement leads={leads} tasks={tasks} />
        </TabsContent>
        
        <TabsContent value="customer-management" className="space-y-6 mt-0">
            <AdminCustomerManagement customers={allCustomers} />
        </TabsContent>

        <TabsContent value="service-management" className="space-y-6 mt-0">
            <AdminServiceManagement />
        </TabsContent>

        <TabsContent value="issues-management" className="space-y-6 mt-0">
            <AdminIssuesManagement complaints={complaints} onResolveComplaint={resolveComplaint} />
        </TabsContent>

        <TabsContent value="vle-special-requests" className="space-y-6 mt-0">
            <AdminSpecialRequests 
              specialRequests={specialRequests} 
              onUpdateStatus={updateSpecialRequestStatus} 
              vleUsers={VLES}
            />
        </TabsContent>
        <TabsContent value="accounting" className="space-y-6 mt-0">
            <AdminWalletManagement />
        </TabsContent>
        <TabsContent value="commissions" className="space-y-6 mt-0">
            <AdminCommissionApproval />
        </TabsContent>
      </motion.div>
    </AdminDashboardLayout>
  );
}
