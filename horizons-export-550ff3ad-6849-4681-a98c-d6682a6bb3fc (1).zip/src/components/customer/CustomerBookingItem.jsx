import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { FileText, Clock, CheckCircle, XCircle, User, MessageSquare, Download, AlertTriangle, Smile, Frown, Eye } from 'lucide-react';
import { Dialog, DialogTrigger, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { useAuth } from '@/hooks/useAuth';


const getStatusIcon = (status) => {
  const icons = {
    pending: <Clock className="h-4 w-4" />,
    assigned: <User className="h-4 w-4" />,
    accepted: <CheckCircle className="h-4 w-4 text-sky-600" />,
    'additional-docs-vle': <MessageSquare className="h-4 w-4 text-orange-600" />,
    'additional-docs-dept': <MessageSquare className="h-4 w-4 text-amber-600" />,
    'ack-submitted': <FileText className="h-4 w-4 text-indigo-600" />,
    'in-progress': <Clock className="h-4 w-4" />,
    completed: <CheckCircle className="h-4 w-4 text-green-600" />,
    rejected: <XCircle className="h-4 w-4 text-red-600" />,
  };
  return icons[status] || <Clock className="h-4 w-4" />;
};

const getStatusColor = (status) => {
  const colors = {
    pending: 'status-pending',
    assigned: 'status-assigned',
    accepted: 'status-accepted',
    'additional-docs-vle': 'status-additional-docs-vle',
    'additional-docs-dept': 'status-additional-docs-dept',
    'ack-submitted': 'status-ack-submitted',
    'in-progress': 'status-in-progress',
    completed: 'status-completed',
    rejected: 'status-rejected',
  };
  return colors[status] || 'status-pending';
};

export function CustomerBookingItem({ booking, tasks, onOpenReUploadDialog, onDownloadCertificate, onOpenComplaintDialog, getCustomerFacingStatus, getLatestRemark }) {
  const displayStatus = getCustomerFacingStatus(booking);
  const associatedTask = tasks.find(t => t.originalId === booking.id && (t.type === booking.type || (booking.type === 'booking' && t.type === 'lead')));
  const { DEMO_USERS } = useAuth();
  
  const canDownloadCertificate = displayStatus === 'completed' && associatedTask?.documents?.some(doc => doc.isCertificate === true);
  const assignedVleDetails = booking.assignedVle ? DEMO_USERS.find(u => u.id === booking.assignedVle) : null;
  const taskDocuments = associatedTask?.documents || [];
  const bookingDocuments = booking.documents || [];
  
  const allDisplayableDocuments = [
    ...bookingDocuments,
    ...taskDocuments.filter(td => !bookingDocuments.some(bd => bd.name === td.name && bd.size === td.size))
  ];


  return (
    <Card className="card-hover animate-fade-in">
      <CardHeader>
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center">
          <div className="mb-2 sm:mb-0">
            <CardTitle className="text-md sm:text-lg">{booking.serviceName}</CardTitle>
            <CardDescription className="text-xs sm:text-sm">Booking ID: {booking.id}</CardDescription>
          </div>
          <Badge className={`${getStatusColor(displayStatus)} flex items-center gap-1 text-xs px-2 py-1`}>
            {getStatusIcon(displayStatus)} {displayStatus.replace(/-/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 sm:gap-4 text-xs sm:text-sm">
          <div><span className="font-medium">Fee:</span> ₹{booking.fee}</div>
          <div><span className="font-medium">Created:</span> {new Date(booking.createdAt).toLocaleDateString()}</div>
          <div>
            <span className="font-medium">Documents:</span> {allDisplayableDocuments.length} files
            <Dialog>
                <DialogTrigger asChild>
                    <Button variant="link" size="sm" className="p-0 h-auto ml-1"><Eye className="h-3 w-3"/></Button>
                </DialogTrigger>
                <DialogContent>
                    <DialogHeader><DialogTitle>View Documents for {booking.serviceName}</DialogTitle></DialogHeader>
                    <div className="py-4 max-h-60 overflow-y-auto">
                        {allDisplayableDocuments.length > 0 ? allDisplayableDocuments.map(doc => (
                            <div key={doc.name + doc.size} className={`text-sm p-1 ${doc.isCertificate ? 'font-semibold text-green-700' : ''}`}>
                                {doc.name} ({(doc.size/1024).toFixed(1)}KB) 
                                {doc.isCertificate && <Badge variant="default" className="ml-2 bg-green-100 text-green-700 border-green-300">Certificate</Badge>}
                            </div>
                        )) : "No documents."}
                    </div>
                </DialogContent>
            </Dialog>
          </div>
          {assignedVleDetails && (<div><span className="font-medium">Assigned VLE ID:</span> {assignedVleDetails.userId}</div>)}
        </div>
        <div className="text-xs sm:text-sm">
          <span className="font-medium">Latest Remark:</span> <span className="text-gray-600">{getLatestRemark(booking)}</span>
        </div>
        <div className="flex flex-wrap gap-2 pt-2">
          {(displayStatus === 'additional-docs-vle' || displayStatus === 'additional-docs-dept') && (
            <Button variant="outline" size="sm" onClick={() => onOpenReUploadDialog(booking)}>Re-upload Documents</Button>
          )}
          {canDownloadCertificate && (
            <Button size="sm" className="bg-green-600 hover:bg-green-700 text-white" onClick={() => onDownloadCertificate(booking)}><Download className="mr-2 h-4 w-4" />Download Certificate</Button>
          )}
          <Button size="sm" variant="outline" onClick={() => onOpenComplaintDialog(booking, 'complaint')}><Frown className="mr-2 h-4 w-4"/>Raise Complaint</Button>
          <Button size="sm" variant="outline" onClick={() => onOpenComplaintDialog(booking, 'feedback')}><Smile className="mr-2 h-4 w-4"/>Give Feedback</Button>
        </div>
      </CardContent>
    </Card>
  );
}
