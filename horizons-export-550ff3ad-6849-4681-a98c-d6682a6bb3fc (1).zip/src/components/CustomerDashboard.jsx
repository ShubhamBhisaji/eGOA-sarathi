
import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useToast } from '@/components/ui/use-toast';
import { useData } from '@/hooks/useData';
import { FileText, MessageSquare, ShieldCheck, LogOut, Settings, Wallet, Menu as MenuIcon, PlusCircle, ListChecks, UserCircle as ProfileIcon } from 'lucide-react';
import { motion } from 'framer-motion';
import { useLocation, useNavigate, useSearchParams } from 'react-router-dom';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator
} from "@/components/ui/dropdown-menu.jsx";

import { CustomerBookingForm } from '@/components/customer/CustomerBookingForm';
import { CustomerBookingItem } from '@/components/customer/CustomerBookingItem';
import { CustomerComplaintItem } from '@/components/customer/CustomerComplaintItem';
import { CustomerReUploadDialog } from '@/components/customer/CustomerReUploadDialog';
import { CustomerComplaintDialog } from '@/components/customer/CustomerComplaintDialog';
import { CustomerWallet } from '@/components/customer/CustomerWallet';
import { CustomerProfile } from '@/components/customer/CustomerProfile';
import { NotificationBell } from '@/components/NotificationBell';

const CUSTOMER_TABS_CONFIG = [
  { value: "my-bookings", label: "My Bookings", icon: <ListChecks className="mr-2 h-4 w-4" /> },
  { value: "book-service", label: "Book New Service", icon: <PlusCircle className="mr-2 h-4 w-4" /> },
  { value: "my-wallet", label: "My Wallet", icon: <Wallet className="mr-2 h-4 w-4" /> },
  { value: "my-complaints", label: "My Issues", icon: <MessageSquare className="mr-2 h-4 w-4" /> },
  { value: "my-profile", label: "My Profile", icon: <ProfileIcon className="mr-2 h-4 w-4" /> },
];

export function CustomerDashboard({ user, onLogout }) {
  const { services,bookings, createBooking, addDocumentsToTask, tasks, createComplaint, complaints, addDocumentsToBooking, addNotification } = useData();
  const { toast } = useToast();
  const location = useLocation();
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();

  const [currentReUploadItem, setCurrentReUploadItem] = useState(null);
  const [isReUploadDialogOpen, setIsReUploadDialogOpen] = useState(false);
  
  const [currentComplaintBooking, setCurrentComplaintBooking] = useState(null);
  const [isComplaintDialogOpen, setIsComplaintDialogOpen] = useState(false);
  const [complaintType, setComplaintType] = useState('complaint'); 
  const [activeTab, setActiveTab] = useState(searchParams.get('tab') || "my-bookings");
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const tabFromUrl = searchParams.get('tab');
    const bookingIdFromUrl = searchParams.get('bookingId');
    const complaintIdFromUrl = searchParams.get('complaintId');

    if (tabFromUrl && CUSTOMER_TABS_CONFIG.find(t => t.value === tabFromUrl)) {
      setActiveTab(tabFromUrl);
    }
    
    if (tabFromUrl === 'my-bookings' && bookingIdFromUrl) {
      const element = document.getElementById(`booking-${bookingIdFromUrl}`);
      if (element) {
        setTimeout(() => element.scrollIntoView({ behavior: 'smooth', block: 'center' }), 100);
      }
    } else if (tabFromUrl === 'my-complaints' && complaintIdFromUrl) {
      const element = document.getElementById(`complaint-${complaintIdFromUrl}`);
      if (element) {
        setTimeout(() => element.scrollIntoView({ behavior: 'smooth', block: 'center' }), 100);
      }
    }
  }, [searchParams]);

  const handleTabChange = (newTab) => {
    setActiveTab(newTab);
    setSearchParams({ tab: newTab });
  };


  const userBookings = bookings.filter(b => b.customerId === user.id).sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  const userComplaintsAndFeedbacks = complaints.filter(c => c.customerId === user.id).sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

  const handleBookService = (serviceId, customerDetails, serviceDocuments) => {
    const documentDetails = serviceDocuments.map(doc => ({ name: doc.name, size: doc.size, type: doc.type, isCertificate: false }));
    const result = createBooking(serviceId, user.id, documentDetails, customerDetails);
    if (result.success) {
        toast({ title: "Service Booked Successfully!", description: `Your booking ID is ${result.booking.id}. You can track its status in 'My Bookings'.`, variant: "default" });
        handleTabChange("my-bookings");
        addNotification(user.id, `Service "${result.booking.serviceName}" booked successfully. ID: ${result.booking.id}`, 'success', `/customer-dashboard?tab=my-bookings&bookingId=${result.booking.id}`, 'Booking Confirmed');
        addNotification('admin-1', `New booking by ${user.name} for service "${result.booking.serviceName}". ID: ${result.booking.id}`, 'info', `/admin-dashboard?tab=all-bookings&bookingId=${result.booking.id}`, 'New Booking Alert');
    } else {
        toast({ title: "Booking Failed", description: result.error || "Could not book service.", variant: "destructive" });
    }
  };

  const handleOpenReUploadDialog = (booking) => {
    setCurrentReUploadItem(booking);
    setIsReUploadDialogOpen(true);
  };

  const handleSubmitReUpload = (item, reUploadedDocs) => {
    const task = tasks.find(t => t.originalId === item.id && (t.type === item.type || (item.type === 'booking' && t.type === 'lead' && t.originalId === item.id)));
    if (!task) {
      toast({ title: "Error Processing Request", description: "Associated task not found. Please contact support.", variant: "destructive" });
      return;
    }
    const reUploadedDocumentDetails = reUploadedDocs.map(doc => ({ name: doc.name, size: doc.size, type: doc.type, isCertificate: false }));
    
    let newStatus = 'accepted'; 
    if (task.status === 'additional-docs-vle' || task.status === 'additional-docs-dept') {
        newStatus = task.taskPhase === 2 ? 'accepted' : 'ack-submitted';
    }

    addDocumentsToTask(task.id, reUploadedDocumentDetails, "Customer re-uploaded documents as requested.", newStatus);
    addDocumentsToBooking(item.id, reUploadedDocumentDetails, "Customer re-uploaded documents as requested.", newStatus);

    toast({ title: "Documents Submitted", description: "Your additional documents have been submitted. The task status is updated and is now under process." });
    addNotification(user.id, `Additional documents submitted for ${item.serviceName}.`, 'info', `/customer-dashboard?tab=my-bookings&bookingId=${item.id}`, 'Documents Submitted');
    if (task.vleId) {
      addNotification(task.vleId, `Customer submitted additional documents for task ${task.id} (${item.serviceName}).`, 'info', `/vle-dashboard?tab=assigned-tasks&taskId=${task.id}`, 'Customer Update');
    }
    addNotification('admin-1', `Customer submitted additional documents for task ${task.id} (${item.serviceName}).`, 'info', `/admin-dashboard?tab=all-bookings&bookingId=${item.id}`, 'Customer Update');


    setIsReUploadDialogOpen(false);
    setCurrentReUploadItem(null);
  };

  const handleDownloadCertificate = (booking) => {
    const task = tasks.find(t => t.originalId === booking.id && (t.type === 'booking' || t.type === 'lead'));
    const certificateDoc = task?.documents?.find(doc => doc.isCertificate === true);
    
    if (certificateDoc && (task.status === 'completed' || task.status === 'pending_commission_approval' || task.status === 'commission_approved' || task.status === 'commission_rejected')) {
      toast({ title: "Certificate Download Initiated", description: `Downloading ${certificateDoc.name}. (This is a simulated download)` });
    } else {
      toast({ title: "Certificate Not Available", description: "No certificate is currently available for this booking or the task is not yet marked as completed.", variant: "destructive" });
    }
  };
  
  const handleOpenComplaintDialog = (booking, type) => {
    setCurrentComplaintBooking(booking);
    setComplaintType(type);
    setIsComplaintDialogOpen(true);
  };

  const handleSubmitComplaint = (booking, subject, description, rating) => {
    const complaintResult = createComplaint(booking.id, user.id, subject, description, rating, complaintType);
    toast({ title: `${complaintType.charAt(0).toUpperCase() + complaintType.slice(1)} Submitted`, description: `Thank you! Your ${complaintType} has been recorded.` });
    addNotification(user.id, `Your ${complaintType} for booking ${booking.id} has been submitted.`, 'info', `/customer-dashboard?tab=my-complaints&complaintId=${complaintResult.id}`, `${complaintType.charAt(0).toUpperCase() + complaintType.slice(1)} Submitted`);
    addNotification('admin-1', `New ${complaintType} submitted by ${user.name} for booking ${booking.id}.`, 'warning', `/admin-dashboard?tab=issues-management&complaintId=${complaintResult.id}`, `New ${complaintType.charAt(0).toUpperCase() + complaintType.slice(1)}`);
    
    setIsComplaintDialogOpen(false);
    setCurrentComplaintBooking(null);
    handleTabChange("my-complaints");
  };

  const getCustomerFacingStatus = (item) => {
    const task = tasks.find(t => t.originalId === item.id && (t.type === item.type || (item.type === 'booking' && t.type === 'lead' && t.originalId === item.id)));
    if (task) {
      if (task.status === 'rejected' && task.history && task.history.length > 0) {
          const latestRemarkEntry = task.history[task.history.length - 1];
          if (latestRemarkEntry && latestRemarkEntry.remarks && latestRemarkEntry.remarks.startsWith('Task rejected by VLE:')) {
              return 'pending_assignment'; 
          }
      }
      if (task.status === 'pending_commission_approval' || task.status === 'commission_approved' || task.status === 'commission_rejected') {
        return 'completed';
      }
      return task.status;
    }
    return item.status; 
  };

  const getLatestRemark = (item) => {
    const task = tasks.find(t => t.originalId === item.id && (t.type === item.type || (item.type === 'booking' && t.type === 'lead' && t.originalId === item.id)));
    const source = task || item;
    if (source.history && source.history.length > 0) {
      const latest = source.history[source.history.length - 1];
      
      const internalRemarksKeywords = ['commission', 'payout', 'VLE internal'];
      if (latest.remarks && internalRemarksKeywords.some(keyword => latest.remarks.toLowerCase().includes(keyword.toLowerCase()))) {
        if (source.status === 'completed' || source.status === 'pending_commission_approval' || source.status === 'commission_approved' || source.status === 'commission_rejected') {
            return "Application processed and completed.";
        }
        for (let i = source.history.length - 2; i >= 0; i--) {
            const prevRemark = source.history[i].remarks;
            if (prevRemark && !internalRemarksKeywords.some(keyword => prevRemark.toLowerCase().includes(keyword.toLowerCase()))) {
                return prevRemark;
            }
        }
        return "Application is under review."; 
      }

      if (source.status === 'rejected' && latest.remarks && latest.remarks.startsWith('Task rejected by VLE:')) {
        return 'Your application is pending initial review. Please check back or contact support for assistance.';
      }
      return latest.remarks || 'No remarks yet.';
    }
    return 'No remarks yet.';
  };
  
  const showNotImplementedToast = (feature = "This feature") => {
    toast({
      title: "🚧 Feature Coming Soon!",
      description: `${feature} isn't implemented yet—but we're working on it! 🚀`,
      variant: "default",
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 font-inter">
      <header className="bg-white/80 backdrop-blur-md shadow-sm border-b border-slate-200 sticky top-0 z-50">
        <div className="max-w-screen-xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-20">
            <div className="flex items-center">
              <ShieldCheck className="h-8 sm:h-10 w-8 sm:w-10 text-primary" />
              <h1 className="ml-2 sm:ml-3 text-2xl sm:text-3xl font-poppins font-bold text-slate-800">eGoa Sarathi</h1>
              <span className="ml-3 sm:ml-4 text-xs sm:text-sm text-slate-500 font-medium hidden md:inline-block">Customer Portal</span>
            </div>
            <div className="flex items-center space-x-1 sm:space-x-3">
              <div className="hidden sm:inline-flex">
                <NotificationBell />
              </div>
              <Button variant="ghost" size="icon" onClick={() => handleTabChange("my-wallet")} aria-label="Wallet" className="hidden sm:inline-flex">
                <Wallet className="h-5 w-5 text-slate-600 hover:text-primary transition-colors"/>
              </Button>
              <Button variant="ghost" size="icon" onClick={() => showNotImplementedToast("Settings")} aria-label="Settings" className="hidden sm:inline-flex">
                <Settings className="h-5 w-5 text-slate-600 hover:text-primary transition-colors"/>
              </Button>
              <Button variant="ghost" size="icon" onClick={() => handleTabChange("my-profile")} aria-label="Profile" className="hidden sm:inline-flex">
                <ProfileIcon className="h-5 w-5 text-slate-600 hover:text-primary transition-colors"/>
              </Button>
              <div className="text-right hidden md:block">
                <span className="text-sm text-slate-700">Hello, <span className="font-medium">{user.name}</span></span>
              </div>
              <Button variant="outline" size="sm" onClick={onLogout} className="border-primary text-primary hover:bg-primary/10">
                <LogOut className="mr-1 sm:mr-2 h-4 w-4"/>Logout
              </Button>
              <div className="sm:hidden">
                <DropdownMenu open={isMobileMenuOpen} onOpenChange={setIsMobileMenuOpen}>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="icon">
                      <MenuIcon className="h-6 w-6 text-slate-600" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-56">
                    {CUSTOMER_TABS_CONFIG.map(tab => (
                       <DropdownMenuItem key={tab.value} onClick={() => { handleTabChange(tab.value); setIsMobileMenuOpen(false); }} className={`flex items-center ${activeTab === tab.value ? "bg-slate-100 text-primary" : ""}`}>
                         {tab.icon} {tab.label}
                       </DropdownMenuItem>
                    ))}
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={() => {setIsMobileMenuOpen(false);}} className="flex items-center">
                       <NotificationBell /> <span className="ml-2">Notifications</span>
                    </DropdownMenuItem>
                     <DropdownMenuItem onClick={() => {showNotImplementedToast("Settings"); setIsMobileMenuOpen(false);}} className="flex items-center">
                      <Settings className="mr-2 h-4 w-4"/> Settings
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-screen-xl mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-10">
        <Tabs value={activeTab} onValueChange={handleTabChange} className="space-y-6">
          <TabsList className="hidden sm:grid w-full grid-cols-5 gap-2 p-1 bg-slate-200/70 rounded-lg">
            {CUSTOMER_TABS_CONFIG.map(tab => (
              <TabsTrigger key={tab.value} value={tab.value} className="text-sm sm:text-base py-2.5 data-[state=active]:bg-white data-[state=active]:text-primary data-[state=active]:shadow-md">
                {tab.label}
              </TabsTrigger>
            ))}
          </TabsList>

          <motion.div 
            key={activeTab}
            initial={{ opacity: 0, y:10 }} 
            animate={{ opacity:1, y:0 }} 
            transition={{duration: 0.3}}
            className="mt-0 sm:mt-6" 
          >
            <TabsContent value="book-service" className="space-y-6 mt-0">
              <CustomerBookingForm services={services} onBookService={handleBookService} user={user} />
            </TabsContent>

            <TabsContent value="my-bookings" className="space-y-6 mt-0">
              {userBookings.length === 0 ? (
                <Card className="shadow-sm border-slate-200 rounded-xl"><CardContent className="text-center py-16"><FileText className="mx-auto h-16 w-16 text-slate-400" /><h3 className="mt-6 text-xl font-poppins text-slate-700">No Bookings Found</h3><p className="mt-2 text-base text-slate-500">Ready to start? Click 'Book New Service' to begin.</p></CardContent></Card>
              ) : (
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {userBookings.map(booking => (
                  <CustomerBookingItem
                    key={booking.id}
                    booking={booking}
                    tasks={tasks}
                    onOpenReUploadDialog={handleOpenReUploadDialog}
                    onDownloadCertificate={handleDownloadCertificate}
                    onOpenComplaintDialog={handleOpenComplaintDialog}
                    getCustomerFacingStatus={getCustomerFacingStatus}
                    getLatestRemark={getLatestRemark}
                    id={`booking-${booking.id}`}
                  />
                ))}
                </div>
              )}
            </TabsContent>
            
            <TabsContent value="my-complaints" className="space-y-6 mt-0">
              {userComplaintsAndFeedbacks.length === 0 ? (
                <Card className="shadow-sm border-slate-200 rounded-xl"><CardContent className="text-center py-16"><MessageSquare className="mx-auto h-16 w-16 text-slate-400" /><h3 className="mt-6 text-xl font-poppins text-slate-700">No Issues Logged</h3><p className="mt-2 text-base text-slate-500">You haven't raised any complaints or provided feedback yet.</p></CardContent></Card>
              ) : (
                <div className="space-y-4">
                {userComplaintsAndFeedbacks.map(item => (
                  <CustomerComplaintItem key={item.id} complaint={item} id={`complaint-${item.id}`} />
                ))}
                </div>
              )}
            </TabsContent>
            <TabsContent value="my-wallet" className="mt-0">
                <CustomerWallet user={user} />
            </TabsContent>
            <TabsContent value="my-profile" className="mt-0">
                <CustomerProfile user={user} />
            </TabsContent>
          </motion.div>
        </Tabs>

        <CustomerReUploadDialog
            isOpen={isReUploadDialogOpen}
            onOpenChange={setIsReUploadDialogOpen}
            item={currentReUploadItem}
            onSubmit={handleSubmitReUpload}
        />
        
        <CustomerComplaintDialog
            isOpen={isComplaintDialogOpen}
            onOpenChange={setIsComplaintDialogOpen}
            booking={currentComplaintBooking}
            onSubmit={handleSubmitComplaint}
            type={complaintType}
        />
      </main>
      <footer className="text-center py-6 sm:py-8 border-t border-slate-200">
          <p className="text-xs sm:text-sm text-slate-500">&copy; {new Date().getFullYear()} eGoa Sarathi. Government of Goa. All rights reserved.</p>
      </footer>
    </div>
  );
}
