import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { useToast } from '@/components/ui/use-toast';
import { LogIn, Mail, Lock, PhoneCall, ShieldCheck, UserPlus, UserCircle, UserCog, UserCheck, Briefcase } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogTrigger } from '@/components/ui/dialog';
import { useAuth } from '@/hooks/useAuth';
import { motion } from 'framer-motion';

export function LoginForm({ onLogin, onQuickLogin, onSignup }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();
  const { DEMO_USERS } = useAuth();

  const [signupName, setSignupName] = useState('');
  const [signupEmail, setSignupEmail] = useState('');
  const [signupPassword, setSignupPassword] = useState('');
  const [signupPhone, setSignupPhone] = useState('');
  const [signupAddress, setSignupAddress] = useState('');
  const [isSignupOpen, setIsSignupOpen] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    const result = onLogin(email, password);
    handleAuthResult(result);
    setLoading(false);
  };

  const handleQuickLogin = async (userId) => {
    setLoading(true);
    const result = onQuickLogin(userId);
    handleAuthResult(result);
    setLoading(false);
  };

  const handleSignupSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    const result = onSignup({ name: signupName, email: signupEmail, password: signupPassword, phone: signupPhone, address: signupAddress });
    handleAuthResult(result, "Signup Successful!");
    if (result.success) {
      setIsSignupOpen(false);
      setSignupName('');
      setSignupEmail('');
      setSignupPassword('');
      setSignupPhone('');
      setSignupAddress('');
    }
    setLoading(false);
  };

  const handleAuthResult = (result, successMessage = "Login Successful!") => {
    if (result.success) {
      toast({
        title: successMessage,
        description: `Welcome to eGoa Sarathi, ${result.user.name}!`,
        variant: 'default', 
      });
    } else {
      toast({
        title: "Action Failed",
        description: result.error,
        variant: "destructive",
      });
    }
  };

  const customerUsers = DEMO_USERS.filter(u => u.role === 'customer');
  const vleUsers = DEMO_USERS.filter(u => u.role === 'vle');
  const adminUser = DEMO_USERS.find(u => u.role === 'admin');

  return (
    <div className="min-h-screen gradient-bg flex items-center justify-center p-4 overflow-hidden">
      <motion.div 
        className="w-full max-w-md space-y-8"
        initial={{ opacity: 0, y: -50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: "easeOut" }}
      >
        <div className="text-center text-white">
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.2, type: "spring", stiffness: 260, damping: 20 }}
          >
            <ShieldCheck className="mx-auto h-20 w-20 mb-4 text-white drop-shadow-lg" />
          </motion.div>
          <h1 className="text-5xl font-poppins font-bold mb-2 drop-shadow-md">eGoa Sarathi</h1>
          <p className="text-xl font-inter opacity-90 drop-shadow-sm">Streamlined Citizen Services</p>
        </div>

        <Card className="glass-effect border-white/20 rounded-xl">
          <CardHeader className="text-center">
            <CardTitle className="flex items-center justify-center gap-2 text-2xl font-poppins text-white">
              <LogIn className="h-6 w-6" />
              Login to Your Portal
            </CardTitle>
            <CardDescription className="text-white/80 font-inter">
              Access services with your credentials or quick login.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="email" className="login-label">Email Address</Label>
                <div className="relative">
                  <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 h-5 w-5 text-white/50" />
                  <Input
                    id="email"
                    type="email"
                    placeholder="your.email@example.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="login-input rounded-lg h-12 text-base"
                    required
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="password" className="login-label">Password</Label>
                <div className="relative">
                  <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 h-5 w-5 text-white/50" />
                  <Input
                    id="password"
                    type="password"
                    placeholder="••••••••"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="login-input rounded-lg h-12 text-base"
                    required
                  />
                </div>
              </div>
              <Button 
                type="submit" 
                className="w-full bg-white text-blue-700 hover:bg-white/90 font-semibold text-base py-3 rounded-lg shadow-md hover:shadow-lg transition-shadow duration-300"
                disabled={loading}
              >
                {loading ? 'Verifying...' : 'Secure Sign In'}
              </Button>
            </form>
          </CardContent>
          <CardFooter className="flex flex-col space-y-4 pt-6">
            <p className="text-sm text-center text-white/70 font-inter">Or login instantly as:</p>
            <div className="grid grid-cols-1 gap-3 w-full">
              {adminUser && (
                <Button variant="outline" className="quick-login-btn" onClick={() => handleQuickLogin(adminUser.id)} disabled={loading}><UserCog className="mr-2 h-4 w-4"/>Admin ({adminUser.userId})</Button>
              )}
              {vleUsers.map(vle => (
                <Button key={vle.id} variant="outline" className="quick-login-btn" onClick={() => handleQuickLogin(vle.id)} disabled={loading}><Briefcase className="mr-2 h-4 w-4"/>{vle.name} ({vle.userId})</Button>
              ))}
              {customerUsers.map(customer => (
                <Button key={customer.id} variant="outline" className="quick-login-btn" onClick={() => handleQuickLogin(customer.id)} disabled={loading}><UserCircle className="mr-2 h-4 w-4"/>{customer.name} ({customer.userId})</Button>
              ))}
            </div>
             <Dialog open={isSignupOpen} onOpenChange={setIsSignupOpen}>
              <DialogTrigger asChild>
                <Button variant="link" className="text-white/80 hover:text-white w-full mt-4 text-sm">
                  <UserPlus className="mr-2 h-4 w-4" /> New Customer? Register Here
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-lg bg-white text-foreground rounded-lg shadow-2xl">
                <DialogHeader>
                  <DialogTitle className="font-poppins text-2xl">New Customer Registration</DialogTitle>
                  <DialogDescription className="font-inter">Create your eGoa Sarathi account to access services.</DialogDescription>
                </DialogHeader>
                <form onSubmit={handleSignupSubmit} className="grid gap-4 py-4">
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="signup-name" className="text-right font-inter">Full Name</Label>
                    <Input id="signup-name" placeholder="Your Full Name" value={signupName} onChange={(e) => setSignupName(e.target.value)} className="col-span-3 rounded-md" required />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="signup-email" className="text-right font-inter">Email</Label>
                    <Input id="signup-email" type="email" placeholder="your.email@example.com" value={signupEmail} onChange={(e) => setSignupEmail(e.target.value)} className="col-span-3 rounded-md" required />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="signup-password" className="text-right font-inter">Password</Label>
                    <Input id="signup-password" type="password" placeholder="Choose a strong password" value={signupPassword} onChange={(e) => setSignupPassword(e.target.value)} className="col-span-3 rounded-md" required />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="signup-phone" className="text-right font-inter">Phone</Label>
                    <Input id="signup-phone" type="tel" placeholder="Your Mobile Number" value={signupPhone} onChange={(e) => setSignupPhone(e.target.value)} className="col-span-3 rounded-md" required />
                  </div>
                   <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="signup-address" className="text-right font-inter">Address</Label>
                    <Input id="signup-address" placeholder="Your Full Address (Optional)" value={signupAddress} onChange={(e) => setSignupAddress(e.target.value)} className="col-span-3 rounded-md" />
                  </div>
                  <Button type="submit" disabled={loading} className="w-full mt-4 py-3 text-base rounded-md bg-primary hover:bg-primary/90 text-primary-foreground">{loading ? 'Creating Account...' : 'Create Account'}</Button>
                </form>
              </DialogContent>
            </Dialog>
          </CardFooter>
        </Card>
        
        <div className="text-center text-white/80 text-sm flex items-center justify-center gap-2 font-inter">
          <PhoneCall className="h-4 w-4" />
          <span>Helpdesk: 1800-123-4567</span>
        </div>
      </motion.div>
      <style jsx>{`
        .quick-login-btn {
          @apply bg-white/5 border-white/20 text-white hover:bg-white/10 backdrop-blur-sm rounded-lg py-3 text-sm font-medium transition-all duration-200 ease-in-out;
        }
        .quick-login-btn:hover {
          transform: translateY(-2px);
          box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }
      `}</style>
    </div>
  );
}
